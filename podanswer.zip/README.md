# PodAnswer

The podcast network where episodes answer the questions people search for. Live at https://podanswer.com.

## How it's built
- Node 22 + Express, server-rendered HTML (no framework), Postgres.
- `src/server.js` routes and SEO plumbing (sitemap, RSS, structured data, click tracking, dashboards, admin).
- `src/views.js` all page templates. `public/` CSS and assets.
- `src/seed.js` loads `data/seed/podcasts/*.json` and `data/seed/blog/*.md` on every deploy (idempotent).
- `src/ingest.js` refreshes episodes from every podcast's RSS feed (daily cron). Members get transcripts.
- `src/generate.js` writes new answer articles for member podcasts with the Anthropic API.

## Environment variables
| Key | Purpose |
|---|---|
| `DATABASE_URL` | Postgres connection string (required) |
| `ADMIN_KEY` | Secret for `/admin?key=...` |
| `SITE_URL` | `https://podanswer.com` |
| `CANONICAL_HOST` | `podanswer.com` (redirects onrender.com and www to it) |
| `CONTACT_EMAIL` | Shown on site |
| `GA_MEASUREMENT_ID` | Google Analytics 4 id (optional) |
| `GSC_VERIFICATION` | Google Search Console meta verification token (optional) |
| `LEAD_WEBHOOK_URL` | POSTs each signup as JSON, e.g. a Make.com webhook (optional) |
| `ANTHROPIC_API_KEY` | For `generate.js` |
| `OPENAI_API_KEY` | For Whisper transcription in `ingest.js` when a feed has no transcript |

## Adding a podcast by hand
Drop a JSON file in `data/seed/podcasts/` (see `data/seed/BRIEF.md` for the schema) and deploy. Or approve a lead in `/admin` and add its feed the same way.

## Making a podcast a paying member
In `/admin`, set its tier to `member` (or `studio`). Ingest will start storing transcripts, and `node src/generate.js <slug> 4` writes four articles for it.

## Local dev
```
export DATABASE_URL=postgres://localhost/podanswer ADMIN_KEY=dev
npm install && npm run build && npm start
```
