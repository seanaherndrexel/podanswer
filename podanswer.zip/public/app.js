// Small progressive enhancements. Site works fully without JS.
(function () {
  // GA4 event on listen clicks if gtag is present
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a.btn-listen');
    if (a && window.gtag) {
      var parts = a.getAttribute('href').split('/');
      gtag('event', 'listen_click', { podcast: parts[2], platform: (parts[3] || '').split('?')[0] });
    }
  });
})();
