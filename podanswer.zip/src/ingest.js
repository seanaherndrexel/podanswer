// Refreshes episodes for every podcast from its RSS feed.
// Run daily as a Render cron job: `node src/ingest.js`
// For member/studio podcasts it also stores transcripts when the feed
// publishes one (<podcast:transcript>), or transcribes new audio when
// OPENAI_API_KEY is set (Whisper). Listed podcasts get metadata only.
const Parser = require('rss-parser');
const { q, pool } = require('./db');
const { slugify } = require('./util');

const parser = new Parser({
  timeout: 20000,
  customFields: {
    item: [['podcast:transcript', 'transcripts', { keepArray: true }], ['itunes:duration', 'duration'], ['itunes:summary', 'itunesSummary']],
    feed: [['itunes:author', 'itunesAuthor'], ['itunes:image', 'itunesImage']],
  },
});

const stripHtml = (s) => String(s || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

function parseDuration(d) {
  if (!d) return null;
  if (/^\d+$/.test(d)) return parseInt(d, 10);
  const parts = String(d).split(':').map(Number);
  if (parts.some(isNaN)) return null;
  return parts.reduce((a, b) => a * 60 + b, 0);
}

async function fetchTranscriptText(url, type) {
  try {
    const r = await fetch(url, { headers: { 'user-agent': 'PodAnswerBot/1.0 (+https://podanswer.com)' } });
    if (!r.ok) return null;
    const text = await r.text();
    if (/json/i.test(type || '') || text.trim().startsWith('{')) {
      try { const j = JSON.parse(text); if (j.segments) return j.segments.map((s) => s.body).join(' '); } catch { /* fallthrough */ }
    }
    if (/srt|vtt/i.test(type || '') || /^WEBVTT/.test(text) || /-->/.test(text)) {
      return text.split('\n').filter((l) => l && !/-->/.test(l) && !/^\d+$/.test(l) && !/^WEBVTT/.test(l)).join(' ').replace(/\s+/g, ' ');
    }
    return stripHtml(text).slice(0, 200000);
  } catch { return null; }
}

async function transcribeAudio(audioUrl) {
  if (!process.env.OPENAI_API_KEY) return null;
  try {
    const audio = await fetch(audioUrl, { redirect: 'follow' });
    if (!audio.ok) return null;
    const blob = await audio.blob();
    if (blob.size > 24 * 1024 * 1024) return null; // Whisper API limit; long episodes need chunking (see README)
    const fd = new FormData();
    fd.append('file', blob, 'episode.mp3');
    fd.append('model', 'whisper-1');
    fd.append('response_format', 'text');
    const r = await fetch('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }, body: fd });
    if (!r.ok) return null;
    return await r.text();
  } catch { return null; }
}

async function ingestPodcast(p, { limit = 25 } = {}) {
  if (!p.feed_url) return { added: 0 };
  let feed;
  try { feed = await parser.parseURL(p.feed_url); } catch (e) { console.warn('feed failed', p.slug, e.message); return { added: 0, error: e.message }; }
  const updates = {};
  if (feed.image && feed.image.url && !p.image_url) updates.image_url = feed.image.url;
  if (feed.itunesImage && feed.itunesImage.$ && feed.itunesImage.$.href && !p.image_url) updates.image_url = feed.itunesImage.$.href;
  if (feed.link && !p.website) updates.website = feed.link;
  if (feed.itunesAuthor && !p.author) updates.author = feed.itunesAuthor;
  if (Object.keys(updates).length) {
    const sets = Object.keys(updates).map((k, i) => `${k}=$${i + 2}`).join(', ');
    await q(`UPDATE podcasts SET ${sets}, updated_at=now() WHERE id=$1`, [p.id, ...Object.values(updates)]);
  }
  let added = 0;
  for (const item of (feed.items || []).slice(0, limit)) {
    const guid = item.guid || item.id || item.link || item.title;
    if (!guid || !item.title) continue;
    const exists = await q(`SELECT id, transcript FROM episodes WHERE podcast_id=$1 AND guid=$2`, [p.id, guid]);
    const summary = stripHtml(item.contentSnippet || item.itunesSummary || item.content || '').slice(0, 1200);
    const audioUrl = item.enclosure && item.enclosure.url;
    const t = (item.transcripts || []).find((x) => x && x.$ && x.$.url);
    const transcriptUrl = t ? t.$.url : '';
    let slug = slugify(item.title);
    if (exists.rows.length) {
      await q(`UPDATE episodes SET title=$3, summary=$4, transcript_url=COALESCE(NULLIF($5,''), transcript_url) WHERE podcast_id=$1 AND guid=$2`, [p.id, guid, item.title, summary, transcriptUrl]);
    } else {
      const clash = await q(`SELECT 1 FROM episodes WHERE podcast_id=$1 AND slug=$2`, [p.id, slug]);
      if (clash.rows.length) slug = `${slug}-${slugify(guid).slice(-8)}`;
      await q(`INSERT INTO episodes (podcast_id, guid, slug, title, published_at, summary, audio_url, duration_sec, episode_url, transcript_url) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [p.id, guid, slug, item.title, item.isoDate ? item.isoDate.slice(0, 10) : null, summary, audioUrl || '', parseDuration(item.duration), item.link || '', transcriptUrl]);
      added++;
    }
    // transcripts only for paying members
    if (p.tier !== 'listed') {
      const row = (await q(`SELECT id, transcript, audio_url, transcript_url FROM episodes WHERE podcast_id=$1 AND guid=$2`, [p.id, guid])).rows[0];
      if (row && !row.transcript) {
        let text = row.transcript_url ? await fetchTranscriptText(row.transcript_url, t && t.$ && t.$.type) : null;
        if (!text && row.audio_url) text = await transcribeAudio(row.audio_url);
        if (text) await q(`UPDATE episodes SET transcript=$2 WHERE id=$1`, [row.id, text]);
      }
    }
  }
  return { added };
}

async function run() {
  const only = process.argv[2]; // optional slug
  // Free listings cost nothing to keep: the daily run only touches paying shows.
  // Pass a slug, or set INGEST_ALL=1, to refresh a free listing on purpose.
  const includeFree = !!only || process.env.INGEST_ALL === '1';
  const where = only ? 'WHERE slug=$1' : (includeFree ? '' : "WHERE tier <> 'listed'");
  const pods = (await q(`SELECT * FROM podcasts ${where} ORDER BY (tier <> 'listed') DESC, updated_at ASC`, only ? [only] : [])).rows;
  let total = 0;
  for (const p of pods) {
    const r = await ingestPodcast(p);
    total += r.added || 0;
    console.log(p.slug, r);
  }
  console.log(`ingest complete: ${total} new episodes across ${pods.length} podcasts`);
}

if (require.main === module) run().then(() => pool.end()).catch((e) => { console.error(e); process.exit(1); });
module.exports = { ingestPodcast };
