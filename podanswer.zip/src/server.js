const express = require('express');
const path = require('path');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const { q, migrate } = require('./db');
const V = require('./views');
const { CATEGORIES, esc, slugify } = require('./util');
const auth = require('./auth');
const billing = require('./billing');
const { articleImage, blogImage } = require('./images');
const { runJob, queueJob } = require('./pipeline');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(compression());
app.post('/webhooks/stripe', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const type = await billing.handleWebhook(req.body, req.get('stripe-signature'));
    console.log('stripe webhook', type);
    res.json({ received: true });
  } catch (e) {
    console.error('stripe webhook failed', e.message);
    res.status(400).send(`Webhook Error: ${e.message}`);
  }
});
app.use(express.urlencoded({ extended: false, limit: '64kb' }));
app.use(express.json({ limit: '256kb' }));
app.use(cookieParser());
app.use((req, res, next) => auth.attachUser(req, res, next));
app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: '7d' }));

const ADMIN_KEY = process.env.ADMIN_KEY || '';
const PAGE = 24;

// canonical host + https
app.use((req, res, next) => {
  const host = req.headers.host || '';
  if (process.env.CANONICAL_HOST && host !== process.env.CANONICAL_HOST && !host.startsWith('localhost')) {
    return res.redirect(301, `https://${process.env.CANONICAL_HOST}${req.originalUrl}`);
  }
  next();
});

const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
const isBot = (ua = '') => /bot|crawl|spider|slurp|facebookexternalhit|preview|fetch|monitor|headless/i.test(ua);

async function logView(req, { podcastId, articleId }) {
  if (isBot(req.get('user-agent'))) return;
  q(`INSERT INTO pageviews (path, podcast_id, article_id, referrer) VALUES ($1,$2,$3,$4)`,
    [req.path.slice(0, 300), podcastId || null, articleId || null, (req.get('referer') || '').slice(0, 300)]).catch(() => {});
}

const ARTICLE_SELECT = `SELECT a.id, a.slug, a.question, a.meta_description, a.published_at, a.updated_at, a.body, a.episode_id,
  p.slug AS podcast_slug, p.title AS podcast_title, p.image_url, p.category, p.author, p.tier
  FROM articles a JOIN podcasts p ON p.id = a.podcast_id WHERE a.status='published'`;

/* ---------- home ---------- */
app.get('/', wrap(async (req, res) => {
  const [stats, feat, pods, counts] = await Promise.all([
    q(`SELECT (SELECT count(*) FROM articles WHERE status='published') AS articles, (SELECT count(*) FROM podcasts) AS podcasts, (SELECT count(*) FROM episodes) AS episodes`),
    q(`${ARTICLE_SELECT} ORDER BY (p.tier <> 'listed') DESC, a.published_at DESC LIMIT 6`),
    q(`SELECT p.* FROM podcasts p ORDER BY p.featured DESC, (p.tier <> 'listed') DESC, p.updated_at DESC LIMIT 8`),
    q(`SELECT category, count(*)::int AS n FROM podcasts GROUP BY category`),
  ]);
  const s = stats.rows[0];
  res.send(V.home({
    stats: { articles: +s.articles, podcasts: +s.podcasts, episodes: +s.episodes },
    featuredArticles: feat.rows, featuredPodcasts: pods.rows,
    counts: Object.fromEntries(counts.rows.map((r) => [r.category, r.n])),
  }));
}));

/* ---------- answers ---------- */
async function renderAnswers(req, res, category) {
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const query = (req.query.q || '').toString().trim().slice(0, 120);
  const params = [];
  let where = '';
  if (category) { params.push(category); where += ` AND p.category = $${params.length}`; }
  if (query) { params.push(`%${query}%`); where += ` AND (a.question ILIKE $${params.length} OR a.meta_description ILIKE $${params.length} OR p.title ILIKE $${params.length})`; }
  params.push(PAGE + 1, (page - 1) * PAGE);
  const r = await q(`${ARTICLE_SELECT} ${where} ORDER BY a.published_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
  const hasMore = r.rows.length > PAGE;
  res.send(V.answersIndex({ articles: r.rows.slice(0, PAGE), category, query, page, hasMore }));
}
app.get('/topics', wrap(async (req, res) => {
  const [counts, popular] = await Promise.all([
    q(`SELECT category, count(*)::int AS n FROM podcasts GROUP BY category`),
    q(`${ARTICLE_SELECT} ORDER BY a.published_at DESC LIMIT 6`),
  ]);
  res.send(V.topicsPage({ counts: Object.fromEntries(counts.rows.map((r) => [r.category, r.n])), popular: popular.rows }));
}));
app.get('/answers', wrap((req, res) => renderAnswers(req, res, null)));
// Old category URLs fold into the topic silo so only one page competes per subject.
app.get('/categories/:cat', (req, res) => res.redirect(301, `/topics/${req.params.cat}`));

app.get('/topics/:topic', wrap(async (req, res) => {
  const topic = req.params.topic;
  const cat = CATEGORIES[topic];
  if (!cat) return res.status(404).send(V.notFound());
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const [arts, pods, count] = await Promise.all([
    q(`${ARTICLE_SELECT} AND p.category=$1 ORDER BY a.published_at DESC LIMIT $2 OFFSET $3`, [topic, PAGE + 1, (page - 1) * PAGE]),
    q(`SELECT * FROM podcasts WHERE category=$1 ORDER BY (tier <> 'listed') DESC, featured DESC, title LIMIT 8`, [topic]),
    q(`SELECT count(*)::int AS n FROM articles a JOIN podcasts p ON p.id=a.podcast_id WHERE p.category=$1 AND a.status='published'`, [topic]),
  ]);
  res.set('Cache-Control', 'public, max-age=300');
  res.send(V.topicHub({
    topic, cat,
    articles: arts.rows.slice(0, PAGE), hasMore: arts.rows.length > PAGE, page,
    podcasts: pods.rows, total: count.rows[0].n,
    siblings: Object.entries(CATEGORIES).filter(([k]) => k !== topic),
  }));
}));

app.get('/answers/:slug', wrap(async (req, res) => {
  const r = await q(`${ARTICLE_SELECT} AND a.slug = $1`, [req.params.slug]);
  if (!r.rows.length) return res.status(404).send(V.notFound());
  const a = r.rows[0];
  const [p, e, related, more] = await Promise.all([
    q(`SELECT * FROM podcasts WHERE slug=$1`, [a.podcast_slug]).then((x) => x.rows[0]),
    a.episode_id ? q(`SELECT * FROM episodes WHERE id=$1`, [a.episode_id]).then((x) => x.rows[0]) : null,
    q(`${ARTICLE_SELECT} AND p.category=$1 AND a.id<>$2 ORDER BY random() LIMIT 3`, [a.category, a.id]).then((x) => x.rows),
    q(`SELECT slug, question FROM articles WHERE podcast_id=(SELECT id FROM podcasts WHERE slug=$1) AND id<>$2 AND status='published' ORDER BY published_at DESC LIMIT 6`, [a.podcast_slug, a.id]).then((x) => x.rows),
  ]);
  logView(req, { podcastId: p.id, articleId: a.id });
  res.set('Cache-Control', 'public, max-age=300');
  res.send(V.articlePage({ a, p, e, related, moreFromShow: more }));
}));

/* ---------- podcasts ---------- */
app.get('/podcasts', wrap(async (req, res) => {
  const category = CATEGORIES[req.query.category] ? req.query.category : null;
  const [pods, counts] = await Promise.all([
    q(`SELECT * FROM podcasts ${category ? 'WHERE category=$1' : ''} ORDER BY (tier <> 'listed') DESC, featured DESC, title ASC`, category ? [category] : []),
    q(`SELECT category, count(*)::int AS n FROM podcasts GROUP BY category`),
  ]);
  res.send(V.podcastsIndex({ podcasts: pods.rows, category, counts: Object.fromEntries(counts.rows.map((r) => [r.category, r.n])) }));
}));

app.get('/podcasts/:slug', wrap(async (req, res) => {
  const p = (await q(`SELECT * FROM podcasts WHERE slug=$1`, [req.params.slug])).rows[0];
  if (!p) return res.status(404).send(V.notFound());
  const [eps, arts] = await Promise.all([
    q(`SELECT * FROM episodes WHERE podcast_id=$1 ORDER BY published_at DESC NULLS LAST LIMIT 30`, [p.id]),
    q(`${ARTICLE_SELECT} AND p.id=$1 ORDER BY a.published_at DESC`, [p.id]),
  ]);
  logView(req, { podcastId: p.id });
  res.set('Cache-Control', 'public, max-age=300');
  res.send(V.podcastPage({ p, episodes: eps.rows, articles: arts.rows, stats: { articles: arts.rows.length, episodes: eps.rows.length } }));
}));

app.get('/podcasts/:slug/episodes/:eslug', wrap(async (req, res) => {
  const p = (await q(`SELECT * FROM podcasts WHERE slug=$1`, [req.params.slug])).rows[0];
  if (!p) return res.status(404).send(V.notFound());
  const e = (await q(`SELECT * FROM episodes WHERE podcast_id=$1 AND slug=$2`, [p.id, req.params.eslug])).rows[0];
  if (!e) return res.status(404).send(V.notFound());
  // full transcripts only for members; listed shows get summary + excerpts inside articles
  if (p.tier === 'listed') e.transcript = null;
  const arts = await q(`${ARTICLE_SELECT} AND a.episode_id=$1`, [e.id]);
  logView(req, { podcastId: p.id });
  res.set('Cache-Control', 'public, max-age=600');
  res.send(V.episodePage({ p, e, articles: arts.rows }));
}));

/* ---------- outbound click tracking ---------- */
app.get('/go/:slug/:platform', wrap(async (req, res) => {
  const p = (await q(`SELECT * FROM podcasts WHERE slug=$1`, [req.params.slug])).rows[0];
  if (!p) return res.status(404).send(V.notFound());
  const map = { apple: p.apple_url, spotify: p.spotify_url, youtube: p.youtube_url, website: p.website, rss: p.feed_url };
  const target = map[req.params.platform];
  if (!target) return res.redirect(302, `/podcasts/${p.slug}`);
  const articleId = parseInt(req.query.a, 10) || null;
  if (!isBot(req.get('user-agent'))) {
    q(`INSERT INTO clicks (podcast_id, article_id, platform, referrer, user_agent) VALUES ($1,$2,$3,$4,$5)`,
      [p.id, articleId, req.params.platform, (req.get('referer') || '').slice(0, 300), (req.get('user-agent') || '').slice(0, 200)]).catch(() => {});
  }
  res.set('Cache-Control', 'no-store');
  res.redirect(302, target);
}));

/* ---------- generated article images ---------- */
app.get('/img/answer/:slug.png', wrap(async (req, res) => {
  const png = await articleImage(req.params.slug);
  if (!png) return res.status(404).end();
  res.set('Content-Type', 'image/png');
  res.set('Cache-Control', 'public, max-age=604800, immutable');
  res.send(png);
}));

app.get('/img/blog/:slug.png', wrap(async (req, res) => {
  const png = await blogImage(req.params.slug);
  if (!png) return res.status(404).end();
  res.set('Content-Type', 'image/png');
  res.set('Cache-Control', 'public, max-age=604800, immutable');
  res.send(png);
}));

/* ---------- accounts ---------- */
app.get('/signup', (req, res) => res.send(V.authPage({ mode: 'signup', next: req.query.next })));
app.post('/signup', wrap(async (req, res) => {
  const b = req.body || {};
  const email = String(b.email || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.send(V.authPage({ mode: 'signup', error: 'Please enter a valid email address.', email }));
  if (String(b.password || '').length < 8) return res.send(V.authPage({ mode: 'signup', error: 'Password needs at least 8 characters.', email }));
  if (await auth.findUserByEmail(email)) return res.send(V.authPage({ mode: 'signup', error: 'That email already has an account. Sign in instead.', email }));
  const user = await auth.createUser({ email, password: b.password, name: b.name });
  if (b.podcast_name) await billing.ensurePodcastForUser(user, { title: b.podcast_name, feedUrl: b.feed_url, category: 'business' });
  auth.setSession(res, user);
  res.redirect(b.next && b.next.startsWith('/') ? b.next : '/account');
}));
app.get('/login', (req, res) => res.send(V.authPage({ mode: 'login', next: req.query.next })));
app.post('/login', wrap(async (req, res) => {
  const b = req.body || {};
  const user = await auth.findUserByEmail(b.email);
  if (!user || !(await auth.check(String(b.password || ''), user.password_hash))) {
    return res.send(V.authPage({ mode: 'login', error: 'Email or password is not right.', email: b.email, next: b.next }));
  }
  auth.setSession(res, user);
  res.redirect(b.next && b.next.startsWith('/') ? b.next : '/account');
}));
app.get('/logout', (req, res) => { auth.clearSession(res); res.redirect('/'); });

async function accountData(user) {
  const podcast = (await q(`SELECT * FROM podcasts WHERE user_id=$1 ORDER BY id LIMIT 1`, [user.id])).rows[0] || null;
  const subscription = (await q(`SELECT * FROM subscriptions WHERE user_id=$1 ORDER BY (status='active') DESC, id DESC LIMIT 1`, [user.id])).rows[0] || null;
  const articles = podcast ? (await q(`SELECT slug, question, published_at FROM articles WHERE podcast_id=$1 AND status='published' ORDER BY published_at DESC`, [podcast.id])).rows : [];
  const jobs = podcast ? (await q(`SELECT * FROM jobs WHERE podcast_id=$1 ORDER BY id DESC LIMIT 10`, [podcast.id])).rows : [];
  const totals = podcast ? (await q(
    `SELECT (SELECT count(*) FROM pageviews WHERE podcast_id=$1 AND created_at > now() - interval '30 days') AS views,
            (SELECT count(*) FROM clicks WHERE podcast_id=$1 AND created_at > now() - interval '30 days') AS clicks`, [podcast.id])).rows[0] : {};
  return { podcast, subscription, articles, jobs, totals };
}

app.get('/account', auth.requireUser, wrap(async (req, res) => {
  const data = await accountData(req.user);
  res.set('Cache-Control', 'no-store');
  res.send(V.accountPage({
    user: req.user, ...data, plans: billing.PLANS, stripeReady: billing.enabled(),
    notice: req.query.welcome ? 'Payment received. Your first batch of answers is being researched and written now, and lands within a day.' : (req.query.saved ? 'Saved.' : (req.query.canceled ? 'Checkout canceled, nothing was charged.' : null)),
  }));
}));

app.post('/account/podcast', auth.requireUser, wrap(async (req, res) => {
  const b = req.body || {};
  await billing.ensurePodcastForUser(req.user, { title: b.title, feedUrl: b.feed_url, category: CATEGORIES[b.category] ? b.category : 'business' });
  res.redirect('/account?saved=1');
}));

app.post('/account/checkout', auth.requireUser, wrap(async (req, res) => {
  if (!billing.enabled()) return res.redirect('/account');
  const { podcast } = await accountData(req.user);
  if (!podcast || !podcast.feed_url) return res.redirect('/account');
  const session = await billing.createCheckout({ user: req.user, plan: req.body.plan, podcast, siteUrl: V.SITE.url });
  res.redirect(303, session.url);
}));

app.post('/account/portal', auth.requireUser, wrap(async (req, res) => {
  if (!billing.enabled()) return res.redirect('/account');
  const session = await billing.billingPortal({ user: req.user, siteUrl: V.SITE.url });
  res.redirect(303, session.url);
}));

/* ---------- job API (Make calls these) ---------- */
const jobAuth = (req, res, next) => {
  const secret = process.env.JOB_SECRET || '';
  const given = req.get('x-job-secret') || req.query.secret || (req.body && req.body.secret) || '';
  return secret && given === secret ? next() : res.status(401).json({ error: 'unauthorized' });
};

app.get('/api/jobs/due', jobAuth, wrap(async (req, res) => {
  const r = await q(`SELECT j.*, p.title AS podcast, p.feed_url FROM jobs j JOIN podcasts p ON p.id=j.podcast_id WHERE j.status='queued' ORDER BY j.id LIMIT 20`);
  res.json({ jobs: r.rows });
}));

app.post('/api/jobs/:id/run', jobAuth, wrap(async (req, res) => {
  const job = await runJob(parseInt(req.params.id, 10));
  res.json({ ok: true, job });
}));

// Kick off a run for one podcast without waiting for a billing event.
app.post('/api/jobs/create', jobAuth, wrap(async (req, res) => {
  const b = req.body || {};
  const podcast = (await q(`SELECT * FROM podcasts WHERE id=$1 OR slug=$2`, [parseInt(b.podcast_id, 10) || 0, b.slug || ''])).rows[0];
  if (!podcast) return res.status(404).json({ error: 'podcast not found' });
  const job = await queueJob({ podcastId: podcast.id, kind: b.kind || 'monthly', quota: parseInt(b.quota, 10) || 4 });
  if (b.run) { try { await runJob(job.id); } catch (e) { return res.status(500).json({ error: e.message, job_id: job.id }); } }
  res.json({ ok: true, job_id: job.id, podcast: podcast.title });
}));

// Monthly sweep: queue a run for every active subscription.
app.post('/api/jobs/monthly', jobAuth, wrap(async (req, res) => {
  const subs = (await q(`SELECT * FROM subscriptions WHERE status='active' AND podcast_id IS NOT NULL`)).rows;
  const made = [];
  for (const s of subs) {
    const job = await queueJob({ podcastId: s.podcast_id, subscriptionId: s.id, kind: 'monthly', quota: s.quota });
    made.push(job.id);
  }
  res.json({ ok: true, queued: made });
}));

/* ---------- static pages ---------- */
app.get('/for-podcasters', (req, res) => res.send(V.forPodcasters()));
app.get('/how-it-works', (req, res) => res.redirect(301, '/for-podcasters'));
app.get('/pricing', (req, res) => res.send(V.pricing()));
app.get('/for-studios', (req, res) => res.send(V.forStudios()));
app.get('/about', (req, res) => res.send(V.about()));
app.get('/privacy', (req, res) => res.send(V.simple('Privacy policy', 'PodAnswer privacy policy.', '/privacy', `
<p>PodAnswer (operated by Mini Machine Creative LLC, doing business as Main Street Creative) collects the information you submit through our forms (name, email, podcast details) so we can respond and provide the service. We record anonymous page views and outbound link clicks to report performance to podcasters. We use Google Analytics and Google Search Console. We do not sell personal information.</p>
<p>Podcast artwork, descriptions and audio shown on this site belong to their creators and are used to describe and link to their shows. To update or remove a listing, email <a href="mailto:${esc(V.SITE.email)}">${esc(V.SITE.email)}</a>.</p>
<p>Questions: Main Street Creative, 152 N Main St, Doylestown, PA 18901.</p>`)));
app.get('/terms', (req, res) => res.send(V.simple('Terms of service', 'PodAnswer terms of service.', '/terms', `
<p>By using PodAnswer you agree to these terms. Content on the site is provided for general information; it summarizes and quotes podcast episodes and is not professional advice. Podcasters who join a paid plan agree to be billed monthly and may cancel at any time; articles already published remain on the site unless removal is requested. We may edit or remove listings at our discretion. These terms are governed by the laws of Pennsylvania.</p>
<p>Contact: <a href="mailto:${esc(V.SITE.email)}">${esc(V.SITE.email)}</a>.</p>`)));

/* ---------- join / leads ---------- */
app.get('/join', (req, res) => res.send(V.joinPage({ plan: req.query.plan, podcast: req.query.podcast, sent: req.query.sent === '1', error: null })));
app.post('/join', wrap(async (req, res) => {
  const b = req.body || {};
  if (b.website_url) return res.redirect('/join?sent=1'); // honeypot
  if (!b.email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(b.email)) return res.send(V.joinPage({ plan: b.plan, podcast: b.podcast_name, sent: false, error: 'Please enter a valid email address.' }));
  await q(`INSERT INTO leads (name, email, podcast_name, feed_url, plan, message, source) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [String(b.name || '').slice(0, 120), String(b.email).slice(0, 200), String(b.podcast_name || '').slice(0, 200), String(b.feed_url || '').slice(0, 500), String(b.plan || 'listed').slice(0, 20), String(b.message || '').slice(0, 2000), (req.get('referer') || '').slice(0, 300)]);
  if (process.env.LEAD_WEBHOOK_URL) {
    fetch(process.env.LEAD_WEBHOOK_URL, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: b.name, email: b.email, podcast_name: b.podcast_name, feed_url: b.feed_url, plan: b.plan, message: b.message, site: 'podanswer.com' }) }).catch(() => {});
  }
  res.redirect('/join?sent=1');
}));

/* ---------- blog ---------- */
app.get('/blog', wrap(async (req, res) => {
  const r = await q(`SELECT slug, title, meta_description, published_at FROM blog_posts ORDER BY published_at DESC`);
  res.send(V.blogIndex({ posts: r.rows }));
}));
// Retired posts point at the article that replaced them, so any existing link keeps its value.
const BLOG_REDIRECTS = {
  'podcast-promotion-services-what-to-expect': 'podcast-promotion-services',
  'podcast-agency-vs-diy-promotion': 'podcast-marketing-agency',
};
app.get('/blog/:slug', wrap(async (req, res) => {
  if (BLOG_REDIRECTS[req.params.slug]) return res.redirect(301, `/blog/${BLOG_REDIRECTS[req.params.slug]}`);
  const b = (await q(`SELECT * FROM blog_posts WHERE slug=$1`, [req.params.slug])).rows[0];
  if (!b) return res.status(404).send(V.notFound());
  const recent = (await q(`SELECT slug, title FROM blog_posts WHERE slug<>$1 ORDER BY published_at DESC LIMIT 5`, [b.slug])).rows;
  logView(req, {});
  res.send(V.blogPost({ b, recent }));
}));

/* ---------- podcaster dashboard ---------- */
app.get('/dashboard/:token', wrap(async (req, res) => {
  const p = (await q(`SELECT * FROM podcasts WHERE dashboard_token=$1`, [req.params.token])).rows[0];
  if (!p) return res.status(404).send(V.notFound());
  const [arts, plat, daily, totals] = await Promise.all([
    q(`SELECT a.id, a.slug, a.question, a.published_at,
         (SELECT count(*) FROM pageviews v WHERE v.article_id=a.id AND v.created_at > now() - interval '30 days')::int AS views,
         (SELECT count(*) FROM clicks c WHERE c.article_id=a.id AND c.created_at > now() - interval '30 days')::int AS clicks
       FROM articles a WHERE a.podcast_id=$1 AND a.status='published' ORDER BY views DESC, a.published_at DESC`, [p.id]),
    q(`SELECT platform, count(*)::int AS n FROM clicks WHERE podcast_id=$1 AND created_at > now() - interval '30 days' GROUP BY platform ORDER BY n DESC`, [p.id]),
    q(`SELECT d::date AS day,
         (SELECT count(*) FROM pageviews v WHERE v.podcast_id=$1 AND v.created_at::date = d::date)::int AS views,
         (SELECT count(*) FROM clicks c WHERE c.podcast_id=$1 AND c.created_at::date = d::date)::int AS clicks
       FROM generate_series(now() - interval '29 days', now(), interval '1 day') d ORDER BY d`, [p.id]),
    q(`SELECT (SELECT count(*) FROM pageviews WHERE podcast_id=$1 AND created_at > now() - interval '30 days') AS views,
              (SELECT count(*) FROM clicks WHERE podcast_id=$1 AND created_at > now() - interval '30 days') AS clicks`, [p.id]),
  ]);
  res.set('Cache-Control', 'no-store');
  res.send(V.dashboard({ p, articles: arts.rows, clicksByPlatform: plat.rows, daily: daily.rows, totals: totals.rows[0] }));
}));

/* ---------- admin ---------- */
const adminOnly = (req, res, next) => (ADMIN_KEY && req.query.key === ADMIN_KEY ? next() : res.status(404).send(V.notFound()));
app.get('/admin', adminOnly, wrap(async (req, res) => {
  const [leads, pods] = await Promise.all([
    q(`SELECT * FROM leads ORDER BY created_at DESC LIMIT 200`),
    q(`SELECT p.*, (SELECT count(*) FROM articles a WHERE a.podcast_id=p.id)::int AS articles FROM podcasts p ORDER BY p.created_at DESC`),
  ]);
  res.set('Cache-Control', 'no-store');
  res.send(V.admin({ leads: leads.rows, podcasts: pods.rows, key: ADMIN_KEY }));
}));
app.post('/admin/tier', adminOnly, wrap(async (req, res) => {
  const tier = ['listed', 'member', 'studio'].includes(req.body.tier) ? req.body.tier : 'listed';
  await q(`UPDATE podcasts SET tier=$1, updated_at=now() WHERE id=$2`, [tier, parseInt(req.body.id, 10)]);
  res.redirect(`/admin?key=${ADMIN_KEY}`);
}));
app.post('/admin/feature', adminOnly, wrap(async (req, res) => {
  await q(`UPDATE podcasts SET featured = NOT featured WHERE id=$1`, [parseInt(req.body.id, 10)]);
  res.redirect(`/admin?key=${ADMIN_KEY}`);
}));
app.get('/admin/leads.csv', adminOnly, wrap(async (req, res) => {
  const r = await q(`SELECT created_at, name, email, podcast_name, feed_url, plan, message FROM leads ORDER BY created_at DESC`);
  const csv = ['created_at,name,email,podcast_name,feed_url,plan,message', ...r.rows.map((l) => [l.created_at.toISOString(), l.name, l.email, l.podcast_name, l.feed_url, l.plan, l.message].map((v) => `"${String(v || '').replace(/"/g, '""')}"`).join(','))].join('\n');
  res.type('text/csv').send(csv);
}));

/* ---------- SEO plumbing ---------- */
app.get('/robots.txt', (req, res) => res.type('text/plain').send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /dashboard/\nDisallow: /go/\nDisallow: /account\nDisallow: /login\nDisallow: /signup\nDisallow: /api/\nSitemap: ${V.SITE.url}/sitemap.xml\n`));

app.get('/sitemap.xml', wrap(async (req, res) => {
  const [arts, pods, eps, posts] = await Promise.all([
    q(`SELECT slug, updated_at FROM articles WHERE status='published' ORDER BY updated_at DESC`),
    q(`SELECT slug, updated_at FROM podcasts`),
    q(`SELECT e.slug, p.slug AS pslug, e.created_at FROM episodes e JOIN podcasts p ON p.id=e.podcast_id WHERE e.transcript IS NOT NULL OR EXISTS (SELECT 1 FROM articles a WHERE a.episode_id=e.id AND a.status='published')`),
    q(`SELECT slug, updated_at FROM blog_posts`),
  ]);
  const u = (loc, lastmod, priority = '0.5', changefreq = 'weekly') => `<url><loc>${esc(V.SITE.url + loc)}</loc>${lastmod ? `<lastmod>${new Date(lastmod).toISOString().slice(0, 10)}</lastmod>` : ''}<changefreq>${changefreq}</changefreq><priority>${priority}</priority></url>`;
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
    [u('/', null, '1.0', 'daily'), u('/answers', null, '0.9', 'daily'), u('/podcasts', null, '0.8'), u('/topics', null, '0.8', 'daily'), u('/pricing', null, '0.7', 'monthly'), u('/for-podcasters', null, '0.8', 'monthly'), u('/for-studios', null, '0.6', 'monthly'), u('/blog', null, '0.7'), u('/about', null, '0.4', 'monthly'), u('/join', null, '0.6', 'monthly'),
      ...Object.keys(CATEGORIES).map((c) => u(`/topics/${c}`, null, '0.9', 'daily')),
      ...arts.rows.map((a) => u(`/answers/${a.slug}`, a.updated_at, '0.8')),
      ...posts.rows.map((b) => u(`/blog/${b.slug}`, b.updated_at, '0.7')),
      ...pods.rows.map((p) => u(`/podcasts/${p.slug}`, p.updated_at, '0.6')),
      ...eps.rows.map((e) => u(`/podcasts/${e.pslug}/episodes/${e.slug}`, e.created_at, '0.4', 'monthly')),
    ].join('\n') + `\n</urlset>`;
  res.set('Cache-Control', 'public, max-age=3600');
  res.type('application/xml').send(xml);
}));

app.get('/feed.xml', wrap(async (req, res) => {
  const r = await q(`${ARTICLE_SELECT} ORDER BY a.published_at DESC LIMIT 30`);
  const items = r.rows.map((a) => `<item><title>${esc(a.question)}</title><link>${V.SITE.url}/answers/${a.slug}</link><guid>${V.SITE.url}/answers/${a.slug}</guid><pubDate>${new Date(a.published_at).toUTCString()}</pubDate><description>${esc(a.meta_description || '')}</description></item>`).join('\n');
  res.type('application/rss+xml').send(`<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>PodAnswer: latest answers</title><link>${V.SITE.url}</link><description>${esc(V.SITE.tagline)}</description>${items}</channel></rss>`);
}));

app.get('/health', (req, res) => res.send('ok'));

app.use((req, res) => res.status(404).send(V.notFound()));
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error(err);
  res.status(500).send(V.simple('Something went wrong', '', '/500', '<p>We hit an error. Please try again in a moment.</p>'));
});

const port = process.env.PORT || 3000;
migrate().then(() => app.listen(port, () => console.log(`PodAnswer listening on ${port}`))).catch((e) => { console.error('migrate failed', e); app.listen(port); });
