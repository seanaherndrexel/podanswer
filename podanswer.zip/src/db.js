// Database layer. Postgres in production (DATABASE_URL), falls back to a
// local in-memory pg-mem-free JSON store is NOT supported: always set DATABASE_URL.
const { Pool } = require('pg');

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  console.error('DATABASE_URL is not set');
}
const pool = new Pool({
  connectionString,
  ssl: connectionString && /render\.com|amazonaws|neon|supabase/.test(connectionString) ? { rejectUnauthorized: false } : undefined,
});

const SCHEMA = `
CREATE TABLE IF NOT EXISTS podcasts (
  id SERIAL PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  author TEXT,
  description TEXT,
  category TEXT NOT NULL,
  website TEXT,
  feed_url TEXT,
  image_url TEXT,
  apple_url TEXT,
  spotify_url TEXT,
  youtube_url TEXT,
  tier TEXT NOT NULL DEFAULT 'listed',   -- listed | member | studio
  featured BOOLEAN NOT NULL DEFAULT false,
  dashboard_token TEXT UNIQUE,
  owner_email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS episodes (
  id SERIAL PRIMARY KEY,
  podcast_id INTEGER NOT NULL REFERENCES podcasts(id) ON DELETE CASCADE,
  guid TEXT NOT NULL,
  slug TEXT NOT NULL,
  title TEXT NOT NULL,
  published_at DATE,
  summary TEXT,
  audio_url TEXT,
  duration_sec INTEGER,
  episode_url TEXT,
  transcript_url TEXT,
  transcript TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (podcast_id, guid),
  UNIQUE (podcast_id, slug)
);
CREATE TABLE IF NOT EXISTS articles (
  id SERIAL PRIMARY KEY,
  podcast_id INTEGER NOT NULL REFERENCES podcasts(id) ON DELETE CASCADE,
  episode_id INTEGER REFERENCES episodes(id) ON DELETE SET NULL,
  slug TEXT UNIQUE NOT NULL,
  question TEXT NOT NULL,
  meta_description TEXT,
  body JSONB NOT NULL,          -- {intro, sections:[{heading, body, quote}], keyTakeaways:[], faq:[], sourceNote}
  status TEXT NOT NULL DEFAULT 'published',
  published_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS blog_posts (
  id SERIAL PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  meta_description TEXT,
  body_md TEXT NOT NULL,
  published_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS clicks (
  id SERIAL PRIMARY KEY,
  podcast_id INTEGER NOT NULL REFERENCES podcasts(id) ON DELETE CASCADE,
  article_id INTEGER REFERENCES articles(id) ON DELETE SET NULL,
  platform TEXT NOT NULL,
  referrer TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS pageviews (
  id SERIAL PRIMARY KEY,
  path TEXT NOT NULL,
  podcast_id INTEGER REFERENCES podcasts(id) ON DELETE CASCADE,
  article_id INTEGER REFERENCES articles(id) ON DELETE CASCADE,
  referrer TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS leads (
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT NOT NULL,
  podcast_name TEXT,
  feed_url TEXT,
  plan TEXT,
  message TEXT,
  source TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_articles_podcast ON articles(podcast_id);
CREATE INDEX IF NOT EXISTS idx_episodes_podcast ON episodes(podcast_id, published_at DESC);
CREATE INDEX IF NOT EXISTS idx_clicks_podcast ON clicks(podcast_id, created_at);
CREATE INDEX IF NOT EXISTS idx_pageviews_podcast ON pageviews(podcast_id, created_at);
CREATE INDEX IF NOT EXISTS idx_pageviews_article ON pageviews(article_id, created_at);
`;

async function migrate() {
  await pool.query(SCHEMA);
  // additive columns for older deployments
  await pool.query(`ALTER TABLE podcasts ADD COLUMN IF NOT EXISTS youtube_url TEXT`);
  await pool.query(`ALTER TABLE podcasts ADD COLUMN IF NOT EXISTS owner_email TEXT`);
}

const q = (text, params) => pool.query(text, params);

module.exports = { pool, q, migrate };

if (require.main === module && process.argv[2] === 'migrate') {
  migrate()
    .then(() => { console.log('migrated'); return pool.end(); })
    .catch((e) => { console.error(e); process.exit(1); });
}
