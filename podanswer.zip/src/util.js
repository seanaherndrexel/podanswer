const crypto = require('crypto');

const CATEGORIES = {
  business: { name: 'Business', blurb: 'Small business, trades, ecommerce and entrepreneurship.' },
  marketing: { name: 'Marketing', blurb: 'Advertising, SEO, social media, branding and sales.' },
  money: { name: 'Money', blurb: 'Personal finance, investing, taxes and retirement.' },
  'real-estate': { name: 'Real Estate', blurb: 'Buying, selling, investing and landlording.' },
  law: { name: 'Law', blurb: 'Plain-English legal answers for families and business owners.' },
  health: { name: 'Health', blurb: 'Sleep, nutrition, longevity and everyday wellness.' },
  fitness: { name: 'Fitness', blurb: 'Strength, running, mobility and training.' },
  science: { name: 'Science', blurb: 'Nature, space, climate and how things work.' },
  history: { name: 'History', blurb: 'Eras, wars, places and the stories behind them.' },
  technology: { name: 'Technology', blurb: 'AI, security, software and tools explained.' },
  productivity: { name: 'Productivity', blurb: 'Habits, focus, time and getting things done.' },
  parenting: { name: 'Parenting', blurb: 'Practical help for every stage of raising kids.' },
  home: { name: 'Home & Garden', blurb: 'Home improvement, gardening and homesteading.' },
  food: { name: 'Food & Drink', blurb: 'Cooking, baking, coffee and wine.' },
  careers: { name: 'Careers', blurb: 'Job search, leadership, freelancing and work life.' },
  education: { name: 'Education', blurb: 'Learning, teaching, languages and school.' },
  psychology: { name: 'Psychology', blurb: 'Relationships, communication and how people think.' },
  creative: { name: 'Creative', blurb: 'Writing, photography, music, video and podcasting.' },
};

function slugify(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 90);
}

function token() {
  return crypto.randomBytes(12).toString('hex');
}

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function fmtDate(d) {
  if (!d) return '';
  const dt = new Date(d);
  if (isNaN(dt)) return '';
  return dt.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC' });
}

function fmtDuration(sec) {
  if (!sec) return '';
  const m = Math.round(sec / 60);
  return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m} min`;
}

module.exports = { CATEGORIES, slugify, token, esc, fmtDate, fmtDuration };
