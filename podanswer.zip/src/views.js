const { marked } = require('marked');
const { CATEGORIES, esc, fmtDate, fmtDuration } = require('./util');

const SITE = {
  name: 'PodAnswer',
  url: process.env.SITE_URL || 'https://podanswer.com',
  tagline: 'The podcast network where episodes answer the questions people search for.',
  email: process.env.CONTACT_EMAIL || 'sean@mainstreetmakes.com',
  gaId: process.env.GA_MEASUREMENT_ID || '',
  gscToken: process.env.GSC_VERIFICATION || '',
};

const md = (s) => marked.parse(String(s || ''), { mangle: false, headerIds: false });

function layout({ title, description, path = '/', body, jsonld = [], ogImage, noindex = false, canonical }) {
  const fullTitle = title ? `${title} | ${SITE.name}` : `${SITE.name}: ${SITE.tagline}`;
  const url = canonical || SITE.url + path;
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(description || SITE.tagline)}">
<link rel="canonical" href="${esc(url)}">
${noindex ? '<meta name="robots" content="noindex,nofollow">' : ''}
<meta property="og:site_name" content="${SITE.name}">
<meta property="og:title" content="${esc(title || SITE.name)}">
<meta property="og:description" content="${esc(description || SITE.tagline)}">
<meta property="og:url" content="${esc(url)}">
<meta property="og:type" content="${path.startsWith('/answers/') || path.startsWith('/blog/') ? 'article' : 'website'}">
${ogImage ? `<meta property="og:image" content="${esc(ogImage)}">` : `<meta property="og:image" content="${SITE.url}/og.png">`}
<meta name="twitter:card" content="summary_large_image">
${SITE.gscToken ? `<meta name="google-site-verification" content="${esc(SITE.gscToken)}">` : ''}
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="alternate" type="application/rss+xml" title="PodAnswer: latest answers" href="/feed.xml">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/styles.css?v=3">
${jsonld.map((j) => `<script type="application/ld+json">${JSON.stringify(j).replace(/</g, '\\u003c')}</script>`).join('\n')}
${SITE.gaId ? `<script async src="https://www.googletagmanager.com/gtag/js?id=${esc(SITE.gaId)}"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','${esc(SITE.gaId)}');</script>` : ''}
</head>
<body>
<header class="nav">
  <div class="wrap nav-in">
    <a class="logo" href="/"><span class="logo-mark">P</span>PodAnswer</a>
    <nav class="nav-links">
      <a href="/answers">Answers</a>
      <a href="/podcasts">Podcasts</a>
      <a href="/how-it-works">How it works</a>
      <a href="/pricing">Pricing</a>
      <a href="/blog">Blog</a>
    </nav>
    <div class="nav-cta">
      <a class="btn btn-ghost" href="/join">Add your podcast</a>
      <a class="btn btn-primary" href="/pricing">Get listeners</a>
    </div>
    <button class="nav-toggle" aria-label="Menu" onclick="document.body.classList.toggle('nav-open')">☰</button>
  </div>
</header>
<main>${body}</main>
<footer class="footer">
  <div class="wrap footer-grid">
    <div>
      <a class="logo" href="/"><span class="logo-mark">P</span>PodAnswer</a>
      <p class="muted">Podcasts get discovered one answered question at a time. We turn what's said on your show into pages that rank on Google and send readers to your episodes.</p>
      <p class="muted small">A Main Street Creative company. Doylestown, PA.</p>
    </div>
    <div>
      <h4>Listeners</h4>
      <a href="/answers">Browse answers</a>
      <a href="/podcasts">All podcasts</a>
      ${Object.entries(CATEGORIES).slice(0, 6).map(([k, v]) => `<a href="/categories/${k}">${esc(v.name)}</a>`).join('')}
    </div>
    <div>
      <h4>Podcasters</h4>
      <a href="/how-it-works">How it works</a>
      <a href="/pricing">Pricing</a>
      <a href="/join">Add your podcast</a>
      <a href="/blog">Podcast growth blog</a>
      <a href="/for-studios">For studios and agencies</a>
    </div>
    <div>
      <h4>Company</h4>
      <a href="/about">About</a>
      <a href="mailto:${esc(SITE.email)}">Contact</a>
      <a href="/privacy">Privacy</a>
      <a href="/terms">Terms</a>
      <a href="/feed.xml">RSS</a>
    </div>
  </div>
  <div class="wrap footer-bottom muted small">© ${new Date().getFullYear()} PodAnswer · Mini Machine Creative LLC. Podcast artwork and audio belong to their creators.</div>
</footer>
<script src="/app.js?v=3" defer></script>
</body>
</html>`;
}

/* ---------- reusable partials ---------- */

function podcastCard(p, { showCategory = true } = {}) {
  return `<a class="card pod-card" href="/podcasts/${esc(p.slug)}">
    <img loading="lazy" src="${esc(p.image_url || '/placeholder.svg')}" alt="${esc(p.title)} artwork" width="96" height="96" onerror="this.src='/placeholder.svg'">
    <div>
      <h3>${esc(p.title)}</h3>
      <p class="muted small">${esc(p.author || '')}</p>
      ${showCategory && CATEGORIES[p.category] ? `<span class="chip">${esc(CATEGORIES[p.category].name)}</span>` : ''}
      ${p.tier === 'member' || p.tier === 'studio' ? '<span class="chip chip-teal">Network member</span>' : ''}
    </div>
  </a>`;
}

function articleCard(a) {
  return `<a class="card art-card" href="/answers/${esc(a.slug)}">
    <div class="art-card-top">
      <img loading="lazy" src="${esc(a.image_url || '/placeholder.svg')}" alt="" width="40" height="40" onerror="this.src='/placeholder.svg'">
      <span class="muted small">${esc(a.podcast_title)}</span>
    </div>
    <h3>${esc(a.question)}</h3>
    <p class="muted">${esc(a.meta_description || '')}</p>
    ${CATEGORIES[a.category] ? `<span class="chip">${esc(CATEGORIES[a.category].name)}</span>` : ''}
  </a>`;
}

function listenButtons(p, articleId) {
  const base = `/go/${esc(p.slug)}/`;
  const qs = articleId ? `?a=${articleId}` : '';
  const btns = [];
  if (p.apple_url) btns.push(`<a class="btn btn-listen" rel="nofollow" href="${base}apple${qs}">Apple Podcasts</a>`);
  if (p.spotify_url) btns.push(`<a class="btn btn-listen" rel="nofollow" href="${base}spotify${qs}">Spotify</a>`);
  if (p.youtube_url) btns.push(`<a class="btn btn-listen" rel="nofollow" href="${base}youtube${qs}">YouTube</a>`);
  if (p.website) btns.push(`<a class="btn btn-listen" rel="nofollow" href="${base}website${qs}">Website</a>`);
  if (p.feed_url) btns.push(`<a class="btn btn-listen" rel="nofollow" href="${base}rss${qs}">RSS</a>`);
  return `<div class="listen">${btns.join('')}</div>`;
}

function categoryGrid(counts = {}) {
  return `<div class="cat-grid">${Object.entries(CATEGORIES).map(([k, v]) => `
    <a class="cat" href="/categories/${k}">
      <strong>${esc(v.name)}</strong>
      <span class="muted small">${esc(v.blurb)}</span>
      ${counts[k] ? `<span class="muted small">${counts[k]} podcast${counts[k] === 1 ? '' : 's'}</span>` : ''}
    </a>`).join('')}</div>`;
}

/* ---------- pages ---------- */

function home({ stats, featuredArticles, featuredPodcasts, counts }) {
  const body = `
<section class="hero">
  <div class="wrap hero-in">
    <p class="eyebrow">A podcast network built for search</p>
    <h1>Every episode becomes an answer <em>people are already looking for.</em></h1>
    <p class="lead">Publishing the next episode is the easy part. Getting found is the hard part. PodAnswer turns what's said on your show into articles that rank on Google, then sends those readers straight to your episodes. Real listeners, found by people who were never going to search for a podcast.</p>
    <div class="hero-cta">
      <a class="btn btn-primary btn-lg" href="/pricing">Get listeners from search</a>
      <a class="btn btn-ghost btn-lg" href="/how-it-works">See how it works</a>
    </div>
    <p class="muted small">Free listing for every podcast · No contract · Built by a working ad agency, not a software startup</p>
  </div>
</section>

<section class="stats">
  <div class="wrap stat-grid">
    <div class="stat"><strong>${stats.articles.toLocaleString()}</strong><span>questions answered</span></div>
    <div class="stat"><strong>${stats.podcasts.toLocaleString()}</strong><span>podcasts on the network</span></div>
    <div class="stat"><strong>${stats.episodes.toLocaleString()}</strong><span>episodes indexed</span></div>
    <div class="stat"><strong>${Object.keys(CATEGORIES).length}</strong><span>subject hubs</span></div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head">
      <h2>Fresh answers from the network</h2>
      <a class="link" href="/answers">Browse all answers →</a>
    </div>
    <div class="grid-3">${featuredArticles.map(articleCard).join('')}</div>
  </div>
</section>

<section class="section section-alt">
  <div class="wrap">
    <div class="section-head"><h2>The loop that turns episodes into listeners</h2></div>
    <div class="loop">
      <div class="loop-step"><span class="num">1</span><h3>Transcribe</h3><p>Your feed comes in automatically. Every episode is transcribed, so the advice inside it finally exists as text Google can read.</p></div>
      <div class="loop-step"><span class="num">2</span><h3>Answer</h3><p>We find the questions people type into Google that your episode already answers, and write a clear article for each one with your best moments highlighted.</p></div>
      <div class="loop-step"><span class="num">3</span><h3>Rank</h3><p>Each article lives in your own hub on PodAnswer, linked to your other answers, so your authority on the subject builds page after page.</p></div>
      <div class="loop-step"><span class="num">4</span><h3>Convert</h3><p>Readers hear the clip, see the show, and click through to subscribe. You see the rankings, the visitors and the clicks in your dashboard.</p></div>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head"><h2>Find a show by what you want to learn</h2><a class="link" href="/podcasts">All podcasts →</a></div>
    ${categoryGrid(counts)}
  </div>
</section>

<section class="section section-alt">
  <div class="wrap">
    <div class="section-head"><h2>On the network</h2></div>
    <div class="grid-4">${featuredPodcasts.map((p) => podcastCard(p)).join('')}</div>
  </div>
</section>

<section class="section cta-band">
  <div class="wrap cta-in">
    <h2>Your show already has the answers. Let people find them.</h2>
    <p>Add your podcast free. Upgrade when you want articles written, tracked and reported every month.</p>
    <div class="hero-cta"><a class="btn btn-primary btn-lg" href="/join">Add your podcast</a><a class="btn btn-ghost-light btn-lg" href="/pricing">See pricing</a></div>
  </div>
</section>`;
  return layout({
    title: '',
    description: 'PodAnswer turns podcast episodes into articles that answer real Google searches and send listeners to the show. Browse answers or add your podcast.',
    path: '/',
    body,
    jsonld: [{
      '@context': 'https://schema.org', '@type': 'WebSite', name: SITE.name, url: SITE.url,
      potentialAction: { '@type': 'SearchAction', target: `${SITE.url}/answers?q={search_term_string}`, 'query-input': 'required name=search_term_string' },
    }, {
      '@context': 'https://schema.org', '@type': 'Organization', name: SITE.name, url: SITE.url, logo: `${SITE.url}/og.png`,
      parentOrganization: { '@type': 'Organization', name: 'Main Street Creative', url: 'https://mainstreetmakes.com' },
    }],
  });
}

function answersIndex({ articles, category, query, page, hasMore }) {
  const cat = category ? CATEGORIES[category] : null;
  const title = cat ? `${cat.name} answers from podcasts` : (query ? `Answers for "${query}"` : 'Questions answered by podcasts');
  const body = `
<section class="page-head"><div class="wrap">
  <h1>${esc(title)}</h1>
  <p class="lead">Real questions, answered with what experts actually said on their shows. Every answer links to the episode it came from.</p>
  <form class="search" action="/answers" method="get"><input type="search" name="q" value="${esc(query || '')}" placeholder="Ask anything, like 'how much should a plumber charge'"><button class="btn btn-primary" type="submit">Search</button></form>
  <div class="chips">${Object.entries(CATEGORIES).map(([k, v]) => `<a class="chip ${k === category ? 'chip-on' : ''}" href="/categories/${k}">${esc(v.name)}</a>`).join('')}</div>
</div></section>
<section class="section"><div class="wrap">
  ${articles.length ? `<div class="grid-3">${articles.map(articleCard).join('')}</div>` : '<p class="muted">No answers yet for that. Try a broader search or browse a subject above.</p>'}
  <div class="pager">${page > 1 ? `<a class="btn btn-ghost" href="?${query ? 'q=' + encodeURIComponent(query) + '&' : ''}page=${page - 1}">← Newer</a>` : ''}${hasMore ? `<a class="btn btn-ghost" href="?${query ? 'q=' + encodeURIComponent(query) + '&' : ''}page=${page + 1}">Older →</a>` : ''}</div>
</div></section>`;
  return layout({ title, description: cat ? `${cat.blurb} Answers pulled from real podcast episodes.` : 'Browse questions answered by podcast hosts and guests, with links to the episodes.', path: category ? `/categories/${category}` : '/answers', body, noindex: !!query || page > 1 });
}

function articlePage({ a, p, e, related, moreFromShow }) {
  const b = a.body;
  const sections = (b.sections || []).map((s) => `
    <h2>${esc(s.heading)}</h2>
    ${md(s.body)}
    ${s.quote && s.quote.text ? `<blockquote class="quote"><p>"${esc(s.quote.text)}"</p><footer>${esc(s.quote.speaker || p.author || p.title)}${s.quote.timestamp ? ` · ${esc(s.quote.timestamp)}` : ''}${e ? ` · <a href="/podcasts/${esc(p.slug)}/episodes/${esc(e.slug)}">${esc(e.title)}</a>` : ''}</footer></blockquote>` : ''}`).join('');
  const faq = (b.faq || []).filter((f) => f.q && f.a);
  const body = `
<article class="article">
  <div class="wrap article-grid">
    <div class="article-main">
      <p class="crumbs"><a href="/answers">Answers</a> › <a href="/categories/${esc(p.category)}">${esc((CATEGORIES[p.category] || {}).name || p.category)}</a></p>
      <h1>${esc(a.question)}</h1>
      <p class="byline">Answered by <a href="/podcasts/${esc(p.slug)}">${esc(p.title)}</a>${p.author ? ` with ${esc(p.author)}` : ''} · ${fmtDate(a.published_at)}</p>
      <p class="lead">${esc(b.intro)}</p>
      ${e ? `<div class="episode-box">
        <img src="${esc(p.image_url || '/placeholder.svg')}" alt="" width="72" height="72" onerror="this.src='/placeholder.svg'">
        <div>
          <p class="small muted">From the episode</p>
          <p><strong><a href="/podcasts/${esc(p.slug)}/episodes/${esc(e.slug)}">${esc(e.title)}</a></strong></p>
          <p class="small muted">${fmtDate(e.published_at)}${e.duration_sec ? ` · ${fmtDuration(e.duration_sec)}` : ''}</p>
          ${e.audio_url ? `<audio controls preload="none" src="${esc(e.audio_url)}"></audio>` : ''}
        </div>
      </div>` : ''}
      ${sections}
      ${(b.keyTakeaways || []).length ? `<div class="takeaways"><h2>What to remember</h2><ul>${b.keyTakeaways.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></div>` : ''}
      ${faq.length ? `<h2>People also ask</h2>${faq.map((f) => `<details class="faq"><summary>${esc(f.q)}</summary><p>${esc(f.a)}</p></details>`).join('')}` : ''}
      ${b.sourceNote ? `<p class="source muted small">${esc(b.sourceNote)}</p>` : ''}
    </div>
    <aside class="article-side">
      <div class="side-card">
        <img src="${esc(p.image_url || '/placeholder.svg')}" alt="${esc(p.title)} artwork" width="120" height="120" onerror="this.src='/placeholder.svg'">
        <h3><a href="/podcasts/${esc(p.slug)}">${esc(p.title)}</a></h3>
        <p class="muted small">${esc(p.author || '')}</p>
        <p class="small">${esc((p.description || '').slice(0, 220))}${(p.description || '').length > 220 ? '…' : ''}</p>
        <p class="small"><strong>Listen and subscribe</strong></p>
        ${listenButtons(p, a.id)}
      </div>
      ${moreFromShow.length ? `<div class="side-card"><h4>More answers from this show</h4>${moreFromShow.map((r) => `<a class="side-link" href="/answers/${esc(r.slug)}">${esc(r.question)}</a>`).join('')}</div>` : ''}
      <div class="side-card side-promo"><h4>Have a podcast?</h4><p class="small">Get articles like this written about your episodes, ranked on Google, and tracked to the click.</p><a class="btn btn-primary btn-sm" href="/pricing">See how</a></div>
    </aside>
  </div>
</article>
${related.length ? `<section class="section section-alt"><div class="wrap"><div class="section-head"><h2>Related answers</h2></div><div class="grid-3">${related.map(articleCard).join('')}</div></div></section>` : ''}`;
  const jsonld = [{
    '@context': 'https://schema.org', '@type': 'Article', headline: a.question, description: a.meta_description,
    datePublished: a.published_at, dateModified: a.updated_at, url: `${SITE.url}/answers/${a.slug}`,
    author: { '@type': 'Person', name: p.author || p.title }, publisher: { '@type': 'Organization', name: SITE.name, logo: { '@type': 'ImageObject', url: `${SITE.url}/og.png` } },
    image: p.image_url || undefined,
    isBasedOn: e ? { '@type': 'PodcastEpisode', name: e.title, url: e.episode_url || `${SITE.url}/podcasts/${p.slug}/episodes/${e.slug}`, datePublished: e.published_at, partOfSeries: { '@type': 'PodcastSeries', name: p.title, url: p.website || `${SITE.url}/podcasts/${p.slug}` } } : undefined,
  }];
  if (faq.length) jsonld.push({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faq.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })) });
  return layout({ title: a.question, description: a.meta_description || b.intro, path: `/answers/${a.slug}`, body, jsonld, ogImage: p.image_url });
}

function podcastsIndex({ podcasts, counts, category }) {
  const cat = category ? CATEGORIES[category] : null;
  const body = `
<section class="page-head"><div class="wrap">
  <h1>${cat ? `${esc(cat.name)} podcasts` : 'Podcasts on the network'}</h1>
  <p class="lead">${cat ? esc(cat.blurb) : 'Educational shows across every subject, each with its episodes indexed and its best answers written up.'}</p>
  <div class="chips">${Object.entries(CATEGORIES).map(([k, v]) => `<a class="chip ${k === category ? 'chip-on' : ''}" href="/podcasts?category=${k}">${esc(v.name)}${counts[k] ? ` (${counts[k]})` : ''}</a>`).join('')}</div>
</div></section>
<section class="section"><div class="wrap"><div class="grid-4">${podcasts.map((p) => podcastCard(p)).join('')}</div></div></section>`;
  return layout({ title: cat ? `${cat.name} podcasts` : 'All podcasts', description: 'Browse every podcast on the PodAnswer network by subject.', path: category ? `/podcasts?category=${category}` : '/podcasts', body, noindex: !!category });
}

function podcastPage({ p, episodes, articles, stats }) {
  const body = `
<section class="pod-head"><div class="wrap pod-head-in">
  <img src="${esc(p.image_url || '/placeholder.svg')}" alt="${esc(p.title)} artwork" width="200" height="200" onerror="this.src='/placeholder.svg'">
  <div>
    <p class="crumbs"><a href="/podcasts">Podcasts</a> › <a href="/categories/${esc(p.category)}">${esc((CATEGORIES[p.category] || {}).name || p.category)}</a></p>
    <h1>${esc(p.title)}</h1>
    ${p.author ? `<p class="byline">Hosted by ${esc(p.author)}</p>` : ''}
    <p>${esc(p.description || '')}</p>
    ${listenButtons(p)}
    <p class="muted small">${stats.articles} question${stats.articles === 1 ? '' : 's'} answered · ${stats.episodes} episode${stats.episodes === 1 ? '' : 's'} indexed</p>
  </div>
</div></section>
<section class="section"><div class="wrap">
  <div class="section-head"><h2>Questions this show answers</h2></div>
  ${articles.length ? `<div class="grid-3">${articles.map(articleCard).join('')}</div>` : '<p class="muted">Answers for this show are on the way.</p>'}
</div></section>
<section class="section section-alt"><div class="wrap">
  <div class="section-head"><h2>Recent episodes</h2></div>
  <div class="ep-list">${episodes.map((e) => `<a class="ep" href="/podcasts/${esc(p.slug)}/episodes/${esc(e.slug)}"><span class="muted small">${fmtDate(e.published_at)}${e.duration_sec ? ` · ${fmtDuration(e.duration_sec)}` : ''}</span><strong>${esc(e.title)}</strong><span class="muted">${esc((e.summary || '').slice(0, 180))}</span></a>`).join('')}</div>
</div></section>
${p.tier === 'listed' ? `<section class="section"><div class="wrap claim"><h2>Is this your show?</h2><p>It's listed free. Claim it to get articles written about your episodes, full transcripts, and a dashboard that shows who's finding you.</p><a class="btn btn-primary" href="/join?podcast=${encodeURIComponent(p.title)}">Claim ${esc(p.title)}</a></div></section>` : ''}`;
  const jsonld = [{
    '@context': 'https://schema.org', '@type': 'PodcastSeries', name: p.title, description: p.description, url: p.website || `${SITE.url}/podcasts/${p.slug}`, image: p.image_url || undefined,
    author: p.author ? { '@type': 'Person', name: p.author } : undefined, webFeed: p.feed_url || undefined,
  }];
  return layout({ title: `${p.title}: episodes and answers`, description: (p.description || '').slice(0, 155), path: `/podcasts/${p.slug}`, body, jsonld, ogImage: p.image_url });
}

function episodePage({ p, e, articles }) {
  const body = `
<section class="page-head"><div class="wrap">
  <p class="crumbs"><a href="/podcasts">Podcasts</a> › <a href="/podcasts/${esc(p.slug)}">${esc(p.title)}</a></p>
  <h1>${esc(e.title)}</h1>
  <p class="byline">${esc(p.title)}${p.author ? ` · ${esc(p.author)}` : ''} · ${fmtDate(e.published_at)}${e.duration_sec ? ` · ${fmtDuration(e.duration_sec)}` : ''}</p>
  ${e.audio_url ? `<audio controls preload="none" src="${esc(e.audio_url)}"></audio>` : ''}
</div></section>
<section class="section"><div class="wrap article-grid">
  <div class="article-main">
    <h2>About this episode</h2>
    <p>${esc(e.summary || '')}</p>
    ${e.transcript ? `<h2>Transcript</h2><div class="transcript">${md(e.transcript)}</div>` : ''}
    ${articles.length ? `<h2>Questions this episode answers</h2><div class="grid-2">${articles.map(articleCard).join('')}</div>` : ''}
    ${e.episode_url ? `<p><a class="link" rel="nofollow" href="${esc(e.episode_url)}">Episode page on the show's site →</a></p>` : ''}
  </div>
  <aside class="article-side"><div class="side-card">
    <img src="${esc(p.image_url || '/placeholder.svg')}" alt="" width="120" height="120" onerror="this.src='/placeholder.svg'">
    <h3><a href="/podcasts/${esc(p.slug)}">${esc(p.title)}</a></h3>
    <p class="small">${esc((p.description || '').slice(0, 200))}</p>
    ${listenButtons(p)}
  </div></aside>
</div></section>`;
  const jsonld = [{
    '@context': 'https://schema.org', '@type': 'PodcastEpisode', name: e.title, description: e.summary, datePublished: e.published_at, url: `${SITE.url}/podcasts/${p.slug}/episodes/${e.slug}`,
    timeRequired: e.duration_sec ? `PT${Math.round(e.duration_sec / 60)}M` : undefined,
    associatedMedia: e.audio_url ? { '@type': 'MediaObject', contentUrl: e.audio_url } : undefined,
    partOfSeries: { '@type': 'PodcastSeries', name: p.title, url: p.website || `${SITE.url}/podcasts/${p.slug}` },
  }];
  return layout({ title: `${e.title} (${p.title})`, description: (e.summary || '').slice(0, 155), path: `/podcasts/${p.slug}/episodes/${e.slug}`, body, jsonld, ogImage: p.image_url });
}

function howItWorks() {
  const body = `
<section class="page-head"><div class="wrap">
  <h1>How a podcast gets found on PodAnswer</h1>
  <p class="lead">Most people don't discover podcasts by searching for podcasts. They discover them by searching for an answer and finding a show that has it. That's the whole idea here.</p>
</div></section>
<section class="section"><div class="wrap prose">
  <h2>The problem with the directories</h2>
  <p>Apple, Spotify and the directory sites list millions of shows. A listing there is a needle in a haystack. Nobody wanders a directory looking for a new podcast about plumbing pricing or estate planning. They type their question into Google, read whatever comes up, and move on with their day.</p>
  <p>That's the moment we put your show in front of them.</p>

  <h2>What happens when you join</h2>
  <div class="steps">
    <div class="step"><span class="num">1</span><div><h3>Your feed connects</h3><p>Give us your RSS feed. Every episode you've published, and every one you publish from now on, comes into your hub on PodAnswer automatically.</p></div></div>
    <div class="step"><span class="num">2</span><div><h3>Episodes get transcribed</h3><p>Audio is invisible to Google. Once it's text, everything your guests and hosts have said becomes something a search engine can read and rank.</p></div></div>
    <div class="step"><span class="num">3</span><div><h3>We find the questions</h3><p>We look at what people actually search for in your subject and match those questions to the moments in your episodes that answer them.</p></div></div>
    <div class="step"><span class="num">4</span><div><h3>Articles get written</h3><p>Each question becomes a clear, readable article with your best passages quoted and the episode embedded. The article credits you as the expert and links to your show on every platform.</p></div></div>
    <div class="step"><span class="num">5</span><div><h3>Your hub builds authority</h3><p>All your answers live together in your own section of the site, linked to each other. Google rewards depth on a subject, so every new article makes the last ones stronger.</p></div></div>
    <div class="step"><span class="num">6</span><div><h3>You see the results</h3><p>Your dashboard shows which articles are ranking, how many people read them, and how many clicked through to listen. A monthly report lands in your inbox.</p></div></div>
  </div>

  <h2>What you can and can't measure</h2>
  <p>We can show you exactly how many people read each article and how many clicked your Apple, Spotify or website links. We can't see inside Apple or Spotify, so we can't tell you which of those clicks became a subscriber. If you add a free download-tracking prefix to your feed (we'll walk you through it), you can watch your downloads move as the articles start ranking.</p>

  <h2>Timelines, honestly</h2>
  <p>New pages take time to rank. Expect the first articles to start appearing in Google within a few weeks and to pick up meaningful traffic over three to six months as your hub fills out. Search traffic compounds, which is the point: an article written this month keeps sending listeners next year.</p>
  <div class="hero-cta"><a class="btn btn-primary btn-lg" href="/pricing">See pricing</a><a class="btn btn-ghost btn-lg" href="/join">Add your podcast free</a></div>
</div></section>`;
  return layout({ title: 'How it works', description: 'How PodAnswer turns podcast episodes into articles that rank on Google and send listeners to your show.', path: '/how-it-works', body });
}

function pricing() {
  const body = `
<section class="page-head"><div class="wrap">
  <h1>Plans for podcasts that want to be found</h1>
  <p class="lead">Every show can be listed free. Paid plans get your episodes transcribed, articles written and ranked, and the results reported to you every month.</p>
</div></section>
<section class="section"><div class="wrap">
  <div class="plans">
    <div class="plan">
      <h3>Listed</h3>
      <p class="price">Free</p>
      <p class="muted">Your show on the network.</p>
      <ul>
        <li>Podcast hub page with your artwork and description</li>
        <li>Recent episodes indexed automatically from your feed</li>
        <li>Listen links to Apple, Spotify and your website</li>
        <li>Eligible to be featured in answers</li>
      </ul>
      <a class="btn btn-ghost" href="/join?plan=listed">List my podcast</a>
    </div>
    <div class="plan plan-featured">
      <span class="chip chip-teal">Most popular</span>
      <h3>Growth</h3>
      <p class="price">$149<span>/month</span></p>
      <p class="muted">Articles written, ranked and reported.</p>
      <ul>
        <li>Everything in Listed</li>
        <li>Every episode transcribed and searchable</li>
        <li>4 answer articles written each month from your episodes</li>
        <li>Your own hub with internal linking that builds authority</li>
        <li>Click tracking on every listen button</li>
        <li>Dashboard with rankings, readers and clicks</li>
        <li>Monthly performance report by email</li>
      </ul>
      <a class="btn btn-primary" href="/join?plan=growth">Start Growth</a>
    </div>
    <div class="plan">
      <h3>Network</h3>
      <p class="price">$349<span>/month</span></p>
      <p class="muted">For shows that publish often and want to own their subject.</p>
      <ul>
        <li>Everything in Growth</li>
        <li>12 answer articles each month</li>
        <li>Back catalog mined for evergreen questions</li>
        <li>Social clip scripts from your best highlighted moments</li>
        <li>Priority placement across the network</li>
        <li>Quarterly strategy call with our team</li>
      </ul>
      <a class="btn btn-ghost" href="/join?plan=network">Start Network</a>
    </div>
  </div>
  <div class="studio-note">
    <h3>Recording with Main Street Creative?</h3>
    <p>Podcast production clients of Main Street Creative get the Growth plan included with their production package. <a class="link" href="/for-studios">Details for studios and agencies →</a></p>
  </div>
  <div class="prose">
    <h2>Common questions</h2>
    <details class="faq"><summary>Do I need to record anything new?</summary><p>No. Everything comes from episodes you've already published. Your feed is the only thing we need.</p></details>
    <details class="faq"><summary>Who writes the articles?</summary><p>Our editorial process uses your transcript to find the moments that answer real search questions, then writes a clear article around them with your words quoted and credited. Every article is reviewed before it goes live, and you can request changes.</p></details>
    <details class="faq"><summary>Where do the articles live?</summary><p>On podanswer.com, in your own hub. That's deliberate: the network's authority is shared, so your articles rank faster than they would on a brand-new site of your own. You can also republish them on your own website.</p></details>
    <details class="faq"><summary>How long until I see listeners?</summary><p>Articles typically start ranking within a few weeks and build over three to six months. Search traffic compounds, so results keep growing as your hub fills out.</p></details>
    <details class="faq"><summary>Can I cancel?</summary><p>Yes, any time. Articles already published stay on the site.</p></details>
  </div>
</div></section>`;
  return layout({ title: 'Pricing', description: 'PodAnswer plans: free listing, or Growth and Network plans that get articles written from your episodes, ranked on Google and reported monthly.', path: '/pricing', body });
}

function forStudios() {
  const body = `
<section class="page-head"><div class="wrap">
  <h1>Built for studios and agencies with podcast clients</h1>
  <p class="lead">If you produce podcasts for clients, the hardest question they ask is "how do we get more listeners?" PodAnswer is the answer you can put in the proposal.</p>
</div></section>
<section class="section"><div class="wrap prose">
  <h2>What your clients get</h2>
  <p>Every show you produce gets its own hub on the network, its episodes transcribed, and a steady stream of articles that rank for the questions its audience is already searching. Your client sees rankings, readers and clicks in a dashboard with their name on it.</p>
  <h2>What you get</h2>
  <ul>
    <li>A promotion line item that's real, measurable and recurring</li>
    <li>Monthly reports you can forward to the client as-is</li>
    <li>Network pricing for five or more shows</li>
    <li>Co-branded dashboards on request</li>
  </ul>
  <p>PodAnswer is run by Main Street Creative, an advertising agency in Doylestown, Pennsylvania, and started as the promotion engine for our own podcast production clients. It works the same for yours.</p>
  <div class="hero-cta"><a class="btn btn-primary btn-lg" href="mailto:${esc(SITE.email)}?subject=PodAnswer%20for%20our%20studio">Talk to us</a></div>
</div></section>`;
  return layout({ title: 'For studios and agencies', description: 'Offer PodAnswer to your podcast production clients: hubs, transcripts, ranked articles and monthly reports under your name.', path: '/for-studios', body });
}

function about() {
  const body = `
<section class="page-head"><div class="wrap"><h1>About PodAnswer</h1><p class="lead">A podcast network that promotes shows the way people actually find things: by searching for an answer.</p></div></section>
<section class="section"><div class="wrap prose">
  <p>PodAnswer was built by <a href="https://mainstreetmakes.com">Main Street Creative</a>, a creative advertising and digital marketing agency in Doylestown, Pennsylvania. We produce podcasts for clients, and every one of them asked the same question after launch: now how do we get listeners?</p>
  <p>Directory listings didn't move the needle. Social clips helped for a day. What worked was writing down what the host said, framing it as the answer to a question people search for, and letting Google do the introducing. PodAnswer is that process turned into a network.</p>
  <p>Podcasts featured on PodAnswer keep full ownership of their audio, artwork and words. Free listings show short summaries and excerpts with credit and links back to the show. If you'd like a show removed or changed, email <a href="mailto:${esc(SITE.email)}">${esc(SITE.email)}</a> and we'll take care of it quickly.</p>
  <p>Main Street Creative · 152 N Main St, Doylestown, PA 18901 · (215) 206-3657</p>
</div></section>`;
  return layout({ title: 'About', description: 'PodAnswer is a podcast network built by Main Street Creative in Doylestown, PA that promotes shows through answered search questions.', path: '/about', body });
}

function joinPage({ plan, podcast, sent, error }) {
  const body = `
<section class="page-head"><div class="wrap"><h1>Add your podcast</h1><p class="lead">Free listings go live after a quick review. Choose a paid plan and we'll reach out within one business day to get your first articles started.</p></div></section>
<section class="section"><div class="wrap form-wrap">
  ${sent ? `<div class="notice">Thanks. We've got it and will be in touch shortly at the email you gave us.</div>` : ''}
  ${error ? `<div class="notice notice-err">${esc(error)}</div>` : ''}
  <form method="post" action="/join" class="form">
    <label>Your name<input name="name" required maxlength="120"></label>
    <label>Email<input name="email" type="email" required maxlength="200"></label>
    <label>Podcast name<input name="podcast_name" required maxlength="200" value="${esc(podcast || '')}"></label>
    <label>RSS feed URL <span class="muted small">(find it in your hosting dashboard)</span><input name="feed_url" type="url" maxlength="500" placeholder="https://feeds.example.com/yourshow"></label>
    <label>Plan
      <select name="plan">
        <option value="listed" ${plan === 'listed' || !plan ? 'selected' : ''}>Listed (free)</option>
        <option value="growth" ${plan === 'growth' ? 'selected' : ''}>Growth ($149/mo)</option>
        <option value="network" ${plan === 'network' ? 'selected' : ''}>Network ($349/mo)</option>
        <option value="studio" ${plan === 'studio' ? 'selected' : ''}>I'm a Main Street Creative client</option>
      </select>
    </label>
    <label>Anything we should know?<textarea name="message" rows="4" maxlength="2000"></textarea></label>
    <input type="text" name="website_url" class="hp" tabindex="-1" autocomplete="off">
    <button class="btn btn-primary btn-lg" type="submit">Send</button>
    <p class="muted small">No payment is taken here. We confirm details with you first.</p>
  </form>
</div></section>`;
  return layout({ title: 'Add your podcast', description: 'List your podcast on PodAnswer free, or start a plan to get articles written from your episodes and ranked on Google.', path: '/join', body, noindex: !!sent });
}

function blogIndex({ posts }) {
  const body = `
<section class="page-head"><div class="wrap"><h1>Podcast growth, without the fluff</h1><p class="lead">Practical notes on getting a podcast found, from the people running the network.</p></div></section>
<section class="section"><div class="wrap grid-2">${posts.map((b) => `<a class="card art-card" href="/blog/${esc(b.slug)}"><span class="muted small">${fmtDate(b.published_at)}</span><h3>${esc(b.title)}</h3><p class="muted">${esc(b.meta_description || '')}</p></a>`).join('')}</div></section>`;
  return layout({ title: 'Podcast promotion blog', description: 'How to promote a podcast, get more listeners, and make episodes rank on Google. Notes from the PodAnswer network.', path: '/blog', body });
}

function blogPost({ b, recent }) {
  const body = `
<article class="article"><div class="wrap article-grid">
  <div class="article-main">
    <p class="crumbs"><a href="/blog">Blog</a></p>
    <h1>${esc(b.title)}</h1>
    <p class="byline">PodAnswer · ${fmtDate(b.published_at)}</p>
    <div class="prose">${md(b.body_md)}</div>
  </div>
  <aside class="article-side">
    <div class="side-card side-promo"><h4>Want listeners from search?</h4><p class="small">PodAnswer writes articles from your episodes that rank on Google and send readers to your show.</p><a class="btn btn-primary btn-sm" href="/pricing">See plans</a></div>
    ${recent.length ? `<div class="side-card"><h4>More from the blog</h4>${recent.map((r) => `<a class="side-link" href="/blog/${esc(r.slug)}">${esc(r.title)}</a>`).join('')}</div>` : ''}
  </aside>
</div></article>`;
  return layout({ title: b.title, description: b.meta_description, path: `/blog/${b.slug}`, body, jsonld: [{ '@context': 'https://schema.org', '@type': 'BlogPosting', headline: b.title, description: b.meta_description, datePublished: b.published_at, dateModified: b.updated_at, author: { '@type': 'Organization', name: 'PodAnswer' }, publisher: { '@type': 'Organization', name: SITE.name } }] });
}

function dashboard({ p, articles, clicksByPlatform, daily, totals }) {
  const maxDay = Math.max(1, ...daily.map((d) => Number(d.views)));
  const body = `
<section class="page-head"><div class="wrap">
  <p class="eyebrow">Podcaster dashboard</p>
  <h1>${esc(p.title)}</h1>
  <p class="lead">Last 30 days on PodAnswer. Bookmark this page; the link is private to you.</p>
</div></section>
<section class="section"><div class="wrap">
  <div class="stat-grid stat-grid-dash">
    <div class="stat"><strong>${Number(totals.views).toLocaleString()}</strong><span>article readers</span></div>
    <div class="stat"><strong>${Number(totals.clicks).toLocaleString()}</strong><span>clicks to listen</span></div>
    <div class="stat"><strong>${totals.views ? ((totals.clicks / totals.views) * 100).toFixed(1) : '0.0'}%</strong><span>reader to click rate</span></div>
    <div class="stat"><strong>${articles.length}</strong><span>articles live</span></div>
  </div>
  <h2>Readers per day</h2>
  <div class="bars">${daily.map((d) => `<div class="bar" title="${esc(d.day)}: ${d.views} readers, ${d.clicks} clicks"><span style="height:${Math.round((Number(d.views) / maxDay) * 100)}%"></span></div>`).join('')}</div>
  <h2>Where listeners clicked</h2>
  <table class="table"><thead><tr><th>Platform</th><th>Clicks</th></tr></thead><tbody>${clicksByPlatform.map((c) => `<tr><td>${esc(c.platform)}</td><td>${c.n}</td></tr>`).join('') || '<tr><td colspan="2" class="muted">No clicks yet.</td></tr>'}</tbody></table>
  <h2>Your articles</h2>
  <table class="table"><thead><tr><th>Question</th><th>Published</th><th>Readers (30d)</th><th>Clicks (30d)</th></tr></thead><tbody>
    ${articles.map((a) => `<tr><td><a href="/answers/${esc(a.slug)}">${esc(a.question)}</a></td><td>${fmtDate(a.published_at)}</td><td>${a.views}</td><td>${a.clicks}</td></tr>`).join('')}
  </tbody></table>
  <p class="muted small">Google Search Console rankings for your articles are included in your monthly email report. Questions? <a href="mailto:${esc(SITE.email)}">${esc(SITE.email)}</a></p>
</div></section>`;
  return layout({ title: `Dashboard: ${p.title}`, description: 'Private dashboard', path: `/dashboard/${p.dashboard_token}`, body, noindex: true });
}

function admin({ leads, podcasts, key }) {
  const body = `
<section class="page-head"><div class="wrap"><h1>Admin</h1></div></section>
<section class="section"><div class="wrap">
  <h2>Leads (${leads.length})</h2>
  <table class="table"><thead><tr><th>When</th><th>Name</th><th>Email</th><th>Podcast</th><th>Feed</th><th>Plan</th><th>Message</th></tr></thead><tbody>
  ${leads.map((l) => `<tr><td>${fmtDate(l.created_at)}</td><td>${esc(l.name)}</td><td><a href="mailto:${esc(l.email)}">${esc(l.email)}</a></td><td>${esc(l.podcast_name)}</td><td>${l.feed_url ? `<a href="${esc(l.feed_url)}">feed</a>` : ''}</td><td>${esc(l.plan)}</td><td>${esc(l.message)}</td></tr>`).join('')}
  </tbody></table>
  <h2>Podcasts (${podcasts.length})</h2>
  <table class="table"><thead><tr><th>Title</th><th>Category</th><th>Tier</th><th>Articles</th><th>Dashboard</th><th></th></tr></thead><tbody>
  ${podcasts.map((p) => `<tr><td><a href="/podcasts/${esc(p.slug)}">${esc(p.title)}</a></td><td>${esc(p.category)}</td><td>
    <form method="post" action="/admin/tier?key=${esc(key)}" class="inline"><input type="hidden" name="id" value="${p.id}"><select name="tier" onchange="this.form.submit()"><option ${p.tier === 'listed' ? 'selected' : ''}>listed</option><option ${p.tier === 'member' ? 'selected' : ''}>member</option><option ${p.tier === 'studio' ? 'selected' : ''}>studio</option></select></form>
  </td><td>${p.articles}</td><td><a href="/dashboard/${esc(p.dashboard_token)}">open</a></td><td><form method="post" action="/admin/feature?key=${esc(key)}" class="inline"><input type="hidden" name="id" value="${p.id}"><button class="btn btn-sm ${p.featured ? 'btn-primary' : 'btn-ghost'}">${p.featured ? 'Featured' : 'Feature'}</button></form></td></tr>`).join('')}
  </tbody></table>
</div></section>`;
  return layout({ title: 'Admin', description: '', path: '/admin', body, noindex: true });
}

function simple(title, description, path, html) {
  return layout({ title, description, path, body: `<section class="page-head"><div class="wrap"><h1>${esc(title)}</h1></div></section><section class="section"><div class="wrap prose">${html}</div></section>` });
}

function notFound() {
  return layout({ title: 'Not found', description: '', path: '/404', noindex: true, body: `<section class="section"><div class="wrap prose"><h1>That page isn't here</h1><p>Try <a href="/answers">browsing answers</a> or <a href="/podcasts">the podcasts</a>.</p></div></section>` });
}

module.exports = { SITE, layout, home, answersIndex, articlePage, podcastsIndex, podcastPage, episodePage, howItWorks, pricing, forStudios, about, joinPage, blogIndex, blogPost, dashboard, admin, simple, notFound };
