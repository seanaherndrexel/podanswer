---
title: How to get podcast sponsors without a huge download number
description: How to get podcast sponsors when your show is small: real rates, CPM vs flat fees, a one-page media kit, and how to pitch advertisers directly.
date: 2026-09-18
slug: how-to-get-podcast-sponsors
---

## Sponsors are buying attention, not downloads

If you want to know how to get podcast sponsors, start with the thing most guides skip. A sponsor is not buying your download count. They're buying access to a group of people who trust you and who might buy their product. A show with 300 downloads an episode where every listener is a licensed electrician is worth more to a tool company than a general interest show with 5,000 downloads, because the electrician show wastes almost nothing.

That changes the whole approach. You stop waiting until you're big enough and start getting specific about who listens. The shows that struggle to sell ads are usually not the small ones. They're the vague ones.

## Define the listener before you define the price

Before you send a single email, describe your audience the way a buyer would think about them. Not "people interested in business." More like "owners of home service companies doing $500k to $3M a year, mostly in the US Northeast, hiring their first office manager."

Once you can write that, you know which companies want to reach those people: software that bills service jobs, uniform suppliers, local insurance brokers, trade schools. None of those advertisers care that you have 400 downloads. They care that 400 is the right 400.

If you can't write those sentences yet, that's the work to do first, and it's the same work that makes everything else easier. Knowing your audience sharpens your topics, your titles and your [approach to getting more podcast listeners](/blog/how-to-get-more-podcast-listeners).

## Three ways money actually changes hands

Most podcast sponsorship deals fall into one of three shapes, and small shows do best with the second and third.

**CPM** means cost per thousand listens. The advertiser pays a rate for every 1,000 downloads the ad is served into. It's the industry standard for mid and large shows and it's a bad deal for small ones, because a rate times a small number is a small number.

**Flat rate** means you sell a spot for a fixed price per episode, per month, or per season, regardless of downloads. This is how local and niche sponsorship usually works, and it's where small shows earn far more than their CPM math would suggest. A local sponsor comparing you to a quarter-page newspaper ad or a radio buy is anchored to those prices, not to podcast CPMs.

**Affiliate and performance** means you get a cut of sales from a promo code or link. There's no ceiling and no floor. It works when the product costs enough to matter and genuinely fits your listeners. It's also the easiest thing for a company that doesn't know you to say yes to, so it's a foot in the door that can convert into a flat rate later.

## What the numbers really look like

Here is the honest shape of podcast sponsorship rates. Treat these as a range, not a promise, because category and audience quality move them a lot.

| Deal type | Typical range | Best for |
|---|---|---|
| CPM, pre-roll (15 to 30 sec) | roughly $15 to $25 per 1,000 | shows past several thousand downloads |
| CPM, mid-roll (60 sec) | roughly $20 to $40 per 1,000 | shows past several thousand downloads |
| Flat local or niche sponsor | $150 to $1,500 a month | small and new shows |
| Affiliate | 5% to 30% of sale | any size, product dependent |

Run the CPM math on a small show and you'll see the problem. At 400 downloads an episode and four episodes a month, a $25 mid-roll CPM pays about $40 a month. That's not a business. The same show selling a local sponsor a $400 monthly package (a read in every episode, a newsletter mention, a logo on the show page) makes ten times that, from a buyer who never asked for a CPM.

That's the answer to how to get sponsors for a small podcast. Don't compete in the ad marketplace where downloads are the only currency. Sell directly, where relevance is.

## The one page you need before you pitch

Your media kit should be one page. Anything longer gets skimmed anyway. Put these on it:

- The show name, what it's about in one sentence, and how long it's been running.
- Who listens, in the specific language you wrote earlier, plus any audience detail you actually have (location, job, company size).
- Downloads per episode, honestly stated as a 30-day average, and total monthly downloads.
- Where listeners come from: the top three apps, top cities or countries.
- What you're offering and what it costs. Actual prices. Making a buyer ask for the price loses deals.
- Two or three sentences of proof: a listener email, a past sponsor's result, a review.
- Your name, email and a link to listen.

Skip the stock photos and the "as heard on" logo wall. Buyers know Apple Podcasts lists everyone.

## Proving your numbers so nobody has to trust you

Sponsors have been burned by inflated claims, so make yours verifiable. Pull stats from your host's dashboard rather than a spreadsheet you maintain, and screenshot it with the date range visible. Use the IAB certified number if your host offers one, since that's what serious buyers recognize.

State the download window you're using. A 30-day figure and a 90-day figure are different animals and quoting the bigger one without labeling it reads as sleight of hand. If you're not sure what range is normal for a show your size, our breakdown of [what counts as a good download number](/blog/how-many-podcast-downloads-is-good) puts it in context.

Then add the numbers that don't come from your host: newsletter subscribers and open rate, traffic to your show page, click-throughs on links you've shared before. A sponsor who sees that your last link got 90 clicks from 400 listeners has a conversion rate to work with, and that beats a download count every time.

## Where small shows actually get podcast sponsors

The question of how to get podcast advertisers is really a question of where to look. Three places work.

### Companies already buying attention near you

Look at who advertises in the trade magazine for your niche, who sponsors the regional conference, who buys the local radio spot. These companies have a budget and a habit of spending it. You're not convincing them to try advertising, only to try you.

### Companies your listeners already mention

Pay attention to the tools, brands and services that come up on your own show and in listener emails. A company whose product your audience already uses is an easy yes, because you can open with evidence that their customers are listening.

### Local businesses in the town you're based in

Local sponsorship is where new shows win. An accountant, a regional bank, a family owned equipment dealer: these buyers already pay for the newspaper, the Little League banner and the chamber directory, and a $300 monthly read sits comfortably next to those. They also renew, because local budgets run on relationships rather than dashboards.

## How to get podcast sponsors to say yes on the second email

Keep it short and make it about them. Name the person, say what your show is and who listens in one sentence, say why their product fits this audience, offer one package with a price, and attach the one-pager. Five sentences is plenty.

Then follow up twice, a week apart. Most yeses come on the second or third touch, not the first, and a cheerful one-line follow-up costs you nothing.

Offer a trial. Two episodes at a reduced rate, with a promo code so results are trackable, removes the risk on their side and gives you a case study either way. If it works, you're renewing a sponsor instead of finding one, which is a much easier job.

## Common questions

### How many downloads do I need before anyone will sponsor me?

There's no minimum for direct and local deals. Shows with a few hundred downloads an episode sell sponsorships regularly when the audience is well defined. Ad networks and marketplaces usually want thousands per episode, which is why direct selling is the route for new shows.

### How do I get sponsors for a new podcast with no history?

Sell the audience you're built for rather than the audience you have, and price it low enough that the risk is small. Offer a founding sponsor rate for a season, be upfront that you're early, and give them extra value like a newsletter mention or a logo on your site. Honesty about your size builds the trust that gets you renewed later.

### Should I use a dynamic ad insertion host or read the ads myself?

Read them yourself for small direct deals. Host-read ads convert better, cost the sponsor nothing to produce, and let you speak about the product in your own words. Dynamic insertion earns its keep once you have a back catalogue worth monetizing and several advertisers to rotate.

## The number that makes the sale easier

Sponsors say yes faster when you can show them attention, not just downloads. That's what PodAnswer builds: we turn your episodes into search articles that answer the questions people are already typing into Google, each one quoting your show with a timestamp, so you get readers, click-throughs and a dashboard that proves both. Have a look at [how it works for podcasters](/for-podcasters) or check the [pricing](/pricing) to see what fits your show.
