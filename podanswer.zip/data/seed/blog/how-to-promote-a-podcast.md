---
title: How to promote a podcast when nobody knows it exists
description: A practical guide to podcast promotion that actually brings listeners: search, guest appearances, clips, and the one channel most shows ignore.
date: 2026-09-10
---

Most podcast promotion advice boils down to "post about it more." That works about as well as you'd expect. Here's what actually moves the listener count, in the order we'd do it if we were starting a show today.

## Start with the people who are already searching

Every day, people type questions into Google that your episodes answer. Somebody wants to know how much a kitchen remodel costs, whether they can fire an employee on probation, or how to train for a first half marathon. If you've covered it, that person should land on your show.

They won't, because your episode is audio and Google can't hear. The fix is to turn the episode into text: a transcript, then a written answer to the specific question, with the episode embedded and a link to subscribe. One article can bring readers for years. That's the model behind [PodAnswer](/how-it-works), and it's the highest-return promotion channel for any educational podcast.

## Go on other shows

Guest appearances are the second-best channel because the audience is already podcast listeners, already interested in your topic, and already trusting the host who introduced you. Pitch shows one or two notches bigger than yours with a specific episode idea, not a bio. Aim for one appearance a month.

## Cut clips that make sense on their own

Short clips work on social, but only when the clip is complete by itself. A 45-second answer to a clear question beats a 45-second reaction shot. Post the clip with the question as the caption. The clips that do best are usually the same moments that make good search articles, so do both from the same highlight.

## Ask your listeners to do one thing

Pick one call to action and repeat it in every episode: follow on Apple, leave a review, or send the episode to one person. Rotating between five asks gets you none of them.

## Fix your titles

Episode titles are the only text most directories index. "Episode 47 with Sarah" tells no one anything. "How Sarah doubled her landscaping revenue without hiring" tells the listener and the algorithm what they're getting.

## Build an email list, even a small one

A hundred subscribers who get one email per episode will out-perform ten thousand social followers. Put a signup link in the show notes and on your site.

## What to skip

Directory submission beyond Apple, Spotify and YouTube. Paid "promotion" services that post your artwork to their feed. Buying followers. Cross-promo swaps with shows that have no audience either.

## Put a number on it

Set a 90-day goal you can measure: downloads per episode in the first week, or clicks from Google to your show. Pick two channels from the list above, do them every week, and check the number monthly. Promotion is a habit, not a launch.

If you'd like the search channel handled for you, [see how PodAnswer works](/how-it-works) or [add your podcast free](/join).
