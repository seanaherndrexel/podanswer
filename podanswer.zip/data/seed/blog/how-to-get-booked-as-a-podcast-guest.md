---
title: How to get booked as a podcast guest and turn it into listeners
description: How to get booked as a podcast guest: picking the right shows, writing a pitch that gets a yes, and making each appearance keep paying afterwards.
date: 2026-09-18
slug: how-to-get-booked-as-a-podcast-guest
---

## The shortest route to an audience that already listens

If you want to know how to get booked as a podcast guest, the mechanics are simple and the discipline is not. You find shows whose audience overlaps yours, you send a specific episode idea to the person who books, and you follow up. Most people fail at the second step, because they send a bio instead of an idea.

Guesting works because of who's on the other end. Someone listening to a podcast has already solved the hard problem of being a podcast listener. They have an app, a routine and a habit. When a host they trust says your name, you're not asking a stranger to change their behaviour. You're asking them to add one show to a list they already keep. After search, it's the highest-converting growth channel available to a small show, and it pairs well with the rest of a [podcast promotion plan](/blog/how-to-promote-a-podcast).

## Where you'll get booked as a podcast guest fastest

Most people who ask how to be a guest on a podcast aim at the biggest show in their category. That's the one with a booking queue, a producer and a hundred pitches a week. Aim instead at shows one or two notches above yours. They have a real audience, they need guests every week, and nobody is fighting you for the slot.

A quick way to sort candidates:

- **Too small.** No reviews, fewer than about ten episodes, no consistent schedule. You'll record for an hour and reach almost nobody, though a few of these are worth doing early for practice and for a clip.
- **Right size.** Publishing regularly for six months or more, a visible review count, an audience clearly adjacent to yours, and a history of booking guests who aren't famous.
- **Too big.** Named sponsors, a producer credit, guests with books out. Come back in a year with a stronger case.

Relevance beats size every time. Forty of the right listeners will follow you. Four thousand of the wrong ones will not.

### Where podcast guest opportunities actually come from

Search Apple Podcasts and Spotify for your topic and sort through who interviews guests. Look at the guest lists of shows you like and note who else those people appeared on, since a guest who fits one show usually fits five. Watch for hosts asking for guests on LinkedIn or in niche communities. And when you have a guest on your own show, ask who else you should talk to. That last one produces the warmest introductions you'll get.

Keep the list in a simple spreadsheet: show, host name, booking email, what you'd pitch, date sent, date followed up. Twenty rows is enough to start.

## Do the listening before you write

Listen to at least two episodes of any show you pitch, including a recent one. You're checking three things: the format, the length, and what the host's audience already knows. If the host has covered your topic three times, your pitch needs a fresh angle or you're asking them to repeat themselves.

Take one note you can use in the pitch. A specific episode you liked, and why, proves in a sentence that you're not blasting a template, and hosts can tell the difference instantly.

## How to pitch yourself to podcasts without sending a resume

Here's the whole reason most pitches get ignored: they describe the guest. The host doesn't need a guest, they need an episode. So pitch an episode.

A pitch that works has five parts and fits on one screen.

1. **A subject line that's the episode title.** "Episode idea: why most contractors lose money on their best jobs" beats "Podcast guest inquiry."
2. **One sentence proving you listened.** Name the episode and what you took from it.
3. **The idea, in two or three sentences.** What the episode would cover and what the listener walks away able to do.
4. **Three to five talking points as bullets.** This is the part hosts actually use. It shows them the episode will have structure.
5. **One line of credibility and your links.** What makes you the person to say this, in a sentence, not a paragraph.

Then stop. No attachments, no media kit in the first email, no "let me know if you'd like to discuss synergies."

Send it to a person. Find the host's name and use it, and if the show has a booking form, use the form, because that's where they look. Follow up once after a week and once after two, then let it go. Short follow-ups win a surprising number of yeses from hosts who meant to reply and forgot.

### A pitch you can copy

> Subject: Episode idea: the pricing mistake that quietly kills small landscaping crews
>
> Hi Dana, I listened to your episode with Marcus on hiring seasonal help and the part about training costs is exactly what I see with clients.
>
> I'd like to propose an episode on how crews price by the hour when they should price by the job, and why it shows up as a cash problem two seasons later.
>
> We could cover: the three signs you're underpriced, how to reprice an existing client without losing them, the one number to track weekly, and what to do when a competitor undercuts you.
>
> I've run a 14-person crew for nine years and now consult for about 30 companies. Show and site linked below. Happy to record any time that suits you.

That's it. Specific, useful, and easy to say yes to.

## What to send once they say yes

Make the host's job easy and you'll get invited back and recommended to others.

- A short bio, one sentence and one paragraph, so they can use whichever fits.
- A headshot and your show artwork.
- The exact URL and spelling of your podcast, plus your handle.
- Three to five questions you're good at answering, phrased as questions.
- Any link you'll mention, so they can drop it in the show notes.

Show up early, use headphones, record in a quiet room with something soft in it, and keep a local backup. Poor audio is the fastest way to be politely not invited back.

## Talking so that listeners actually go find you

A good appearance and a useful appearance are different things. Listeners follow you when you've given them something before you ask for anything.

Answer the question that was asked in the first ten seconds, then explain. Tell specific stories with names, numbers and dates, because specificity is what makes someone remember you an hour later. Say your show's name in the middle of the conversation, not only in the outro, and say it in a form people can search, so "the Small Crew Podcast, same name in any app" rather than a URL nobody will type.

Give one call to action, once, at the end. Pick the single thing you want, usually "search the show name and hit follow." Two asks gets you neither. And if you offer a resource, make the link short and memorable and mention it twice.

## Getting booked as a podcast guest again, and again

The episode goes live and most guests do nothing. That's where the value leaks out.

Share the episode with your own audience and tag the host, which is the cheapest thanks you can give and often earns a repeat invite. Pull a 45 second clip of your best answer and post it with the question as the caption. Add the appearance to your site and show notes.

Then email the host two weeks later with something useful: a listener question you both got, or a guest referral. Hosts remember the guests who make their lives easier, and referrals travel between shows constantly.

Finally, mine the episode for your own content. The questions the host asked are questions your audience has too, so make them episodes of your own show. If you'd rather grow without living on social platforms, this loop stacks neatly with [growing a podcast without social media](/blog/how-to-grow-a-podcast-without-social-media).

## Common questions

### How many shows should I pitch to get one booking?

A specific, well researched pitch to a cold list tends to convert somewhere between one in five and one in ten. Send ten thoughtful pitches, not a hundred templated ones. Warm introductions do far better, which is why asking every host for a referral pays.

### How do I get booked as a podcast guest with no audience of my own?

Hosts book interesting, not popular. Lead with the expertise, story or data you have, and pitch a topic their listeners want. Plenty of hosts book guests with no podcast and no following, because the episode has to be good, not famous.

### Should I pay a podcast guest booking service?

You don't need one to start, and doing your own pitching teaches you what lands. Twenty well researched pitches you write yourself will usually outperform a bulk campaign, because hosts can tell when a human listened to their show.

## Where the other half of the growth comes from

Guesting reaches people who are already listening to podcasts. Search reaches everyone else, and that's the gap PodAnswer fills: we turn your episodes into articles that answer the questions people type into Google, each answer quoted from your show with a timestamp and a link back to your feed. See [what we do for podcasters](/for-podcasters), or [sign up](/signup) and get your show listed for free.
