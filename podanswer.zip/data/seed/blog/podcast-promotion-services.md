---
title: Podcast promotion services: what you're actually buying
description: A skeptical guide to podcast promotion services. The four categories, the red flags, honest price bands, and how to judge one in a single call.
date: 2026-09-18
slug: podcast-promotion-services
---

Most podcast promotion services sell one of four things, and only one of them puts your show in front of people who have never heard of you. Prices run from twenty dollars to five figures a month, and the price tells you almost nothing about which category you're in. Before you pay anyone, the useful question isn't whether a service is good. It's what specific work they do, and whether that work reaches strangers.

## The four categories, and which one you need

Nearly every offer falls into one of these buckets, and knowing which one you're looking at solves most of the confusion.

**Discovery.** Getting your show in front of people who don't know it exists. Search articles, guest bookings on other shows, editorial placement in newsletters, paid ads inside podcast apps. It's the only category that grows the top of your funnel, and the hardest to do well.

**Activation.** Reaching people who already follow you and getting them to listen more often. Social clips, email sequences, community management. Useful once you have an audience, close to worthless when you don't. If you have 200 downloads an episode, cutting audiograms for an Instagram account with 80 followers is not promotion.

**Production.** Editing, titling, show notes, artwork, feed hygiene. Real work that makes the show better, but not promotion, though plenty of services sell it under that label.

**Vanity.** Downloads, plays, followers and reviews bought in bulk. This one is fraud with a price list, and there's more on it below.

If a pitch doesn't make obvious which of these it is, that's your first signal.

## What "paid podcast promotion" actually covers

In practice it means one of three things. In-app advertising, where you buy impressions inside a podcast player and your show is pitched to listeners of similar shows. Newsletter or editorial placement, where you pay to be featured in something people already read. Or paid social and search ads pointing at an episode.

All three are legitimate, and all three share a problem: podcast listening is high friction. Someone has to see the ad, care enough to tap, land somewhere, and then commit twenty minutes of attention. Cost per new follower is usually measured in dollars, not cents. It works, but it's expensive and it stops the day you stop paying.

## The offers that should end the conversation

These are specific, and they come up constantly. If you see any of them, you're in the vanity bucket.

- **Guaranteed downloads.** Nobody can guarantee downloads, because nobody controls whether humans press play. A guarantee means a bot farm or a download-swap scheme. Both violate platform terms, both pollute your analytics, and IAB-certified hosts filter much of it out anyway, so you may pay for numbers you never see.
- **Bot plays or streaming farms.** The Spotify version. Fake plays wreck your completion rate, and completion rate is what Spotify's recommendation systems read. You can make your show harder to recommend by buying plays.
- **Submission to 50+ directories.** Maybe a dozen directories send measurable traffic, and your host pushes to nearly all of them free in about five minutes. It isn't harmful, it's just not worth money.
- **Follower or review packages.** Bought reviews get detected and removed, and the show can get penalized. [Asking your actual listeners](/blog/how-to-get-more-podcast-reviews) works better and costs nothing.
- **"We'll get you on charts."** Chart position is driven by new followers in a short window. Manufacturing that is chart manipulation, and platforms actively police it.

One softer flag: a service that talks entirely in reach and "exposure" without naming a deliverable. An article, a booked interview, a placement, those are deliverables. Exposure isn't.

## What a real service hands you

Legitimate promotion produces artifacts. You should be able to open a link and see the thing you paid for.

| What you're buying | The actual deliverable | What should get reported |
|---|---|---|
| Search content | Published pages or articles about your show's topics | URLs, impressions, clicks through to your show |
| Guest booking | Confirmed interviews on other podcasts | Show names, audience size, air dates, recorded episodes |
| In-app ads | Impressions in a podcast player | Spend, impressions, new followers attributable to the campaign |
| Newsletter placement | A dated feature in a named publication | Screenshot or link, subscriber count, clicks |
| Social and clips | A defined number of edited clips, posted | Post links, views, saves, profile clicks |
| Production support | Edited audio, notes, artwork, feed fixes | The files, and a changelog |

Every row ends in a link or a file. If a service can't produce that, there's nothing to check. Reporting should be equally specific. A good monthly report says what was published or booked, what traffic it drew, and what that traffic did. A bad one is a screenshot of your download graph with an arrow drawn on it.

## Honest price bands

These are rough market ranges, not quotes. Use them to spot when something is priced strangely.

Under $100 a month you're buying either a small amount of production work or something from the vanity bucket. There are honest freelancers here doing clips or show notes, and a lot of junk.

Between $100 and $500 a month is where most real, narrow services live. One clear deliverable, done consistently. A set number of published pages, a few pitched guest spots, a managed clip schedule. This is the band where independent shows usually get the best return, because the work is specific enough to judge.

Between $500 and $2,000 a month buys a combination, usually a small agency doing two or three of the categories with a named account contact. Reasonable if your show already earns money and you can tell whether the spend is paying back.

Above $2,000 a month is retainer territory, usually strategy plus execution across several channels. That fits when a podcast is a marketing channel for a business with real customer value, and rarely fits a hobby show. Our breakdown of [what a podcast marketing agency does](/blog/podcast-marketing-agency) covers when a retainer makes sense. Media buying sits outside all of this, since most of that budget is the ad spend and the fee is a percentage on top.

## Are podcast promotion services worth it?

Sometimes, and the deciding factor usually isn't the service. It's whether your show is ready. Promotion amplifies what exists. If people who find your episodes stick around, paid help can be the fastest way to grow. If retention is poor, spending on discovery just buys you more people who leave.

The other honest answer is that much of this work you can do yourself, at the cost of time instead of money. If you have more time than budget, work through [the DIY approach](/blog/how-to-promote-a-podcast) first and buy help only for the parts you can't sustain.

## Sizing up podcast promotion services in one conversation

You can sort this out in twenty minutes. Ask these, and watch how fast the answers get vague.

1. **What exactly will exist at the end of month one?** You want nouns. Twelve articles. Four booked interviews. A campaign with a named spend.
2. **Show me that work for another client.** Live links, not a slide deck. Anyone doing real work has public examples.
3. **How will I know it worked?** The answer should reference something measurable that isn't total downloads, because downloads move for a dozen reasons.
4. **What's the minimum commitment, and what happens to the work if I leave?** Content you paid for should stay published. Find out if it does.
5. **Who does the work?** The person on the call, a team, or a subcontractor. Decide with that in mind.

If they guarantee a number, decline. If they can't name a deliverable, decline. If the case studies are screenshots of graphs with no client name, decline.

## Common questions

### How long before promotion shows results?

It depends on the category. Paid ads move within days because you're buying impressions directly. Search work takes two to four months, because pages need to get indexed and rank. Guest spots land in bursts whenever an episode airs. Anyone promising fast organic growth is describing paid growth or fake growth.

### Can I just use podcast promotion packages instead of doing it myself?

You can, but don't outsource something you've never tried. Run one month yourself first, even badly. You'll learn what the work involves, which makes you harder to overcharge and better at judging whether the vendor is doing it.

### Does paying for promotion hurt my show?

Legitimate promotion doesn't. Vanity metrics can. Fake downloads and fake plays distort your analytics, which means you lose the ability to tell what's working, and they can damage how recommendation systems treat your show. It's also a problem if you ever [pitch sponsors](/blog/how-to-get-podcast-sponsors), since inflated numbers fall apart under any real audit.

## Where we fit

PodAnswer sits squarely in the discovery category, and narrowly. We take your RSS feed, transcribe every episode, find the questions people are already typing into Google in your subject, and publish the moments in your episodes that answer them as articles with timestamped quotes that link back to your show. You get URLs you can open and a dashboard showing readers and click-throughs, which is exactly the kind of deliverable this article argues you should demand. Listing is [free for any podcast](/for-podcasters), and the paid packages with a set number of answers published each month are on the [pricing page](/pricing).
