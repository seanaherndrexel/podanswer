---
title: How many podcast downloads is good?
description: How many podcast downloads is good? Rough benchmark bands by episode age, what a download counts, and the numbers worth watching instead.
date: 2026-09-18
slug: how-many-podcast-downloads-is-good
---

If you are asking how many podcast downloads is good, the short version is this: roughly 30 downloads in the first month puts an episode near the middle of all podcasts, a couple hundred puts you in the top tenth or so, and a thousand puts you somewhere near the top few percent. Those figures move around and every source reports them a little differently, so treat them as bands rather than scores. The longer version is that the number you are worrying about is probably not the one that decides whether your show works.

## The comparison you are making is against a ghost

Almost everyone who searches this has a figure in their head that came from somewhere unreliable. A friend's show. A podcast conference stage. A tweet about a show with a full time producer and a network behind it.

The real distribution is nothing like that. There are a few million podcast feeds in existence, the large majority publish rarely or stopped years ago, and among active independent shows the typical episode is heard by a number of people that would fit in a school assembly. Average podcast downloads per episode, quoted as a plain average, is a misleading statistic because a handful of enormous shows drag the mean far above what any normal show experiences. Medians and percentiles tell you much more, which is why hosting companies report them that way.

## How many podcast downloads is good, in rough bands

Here is the shape of it. These come from figures that podcast hosting platforms publish periodically, rounded hard on purpose, because the exact numbers shift with each report and precision here would be false comfort.

| Downloads per episode | 7 days after release | 30 days after release | Roughly where that sits |
|---|---|---|---|
| Under 20 | Common | Common | Bottom half of all podcasts |
| 20 to 50 | Solid start | Middle of the pack | Around the median |
| 50 to 150 | Strong | Good | Top quarter |
| 150 to 500 | Very strong | Very strong | Roughly top 10% |
| 500 to 1,500 | Unusual | Unusual | Roughly top 5% |
| 1,500 and up | Rare | Rare | Around the top 1% |

Two things about this table. First, an episode keeps accumulating after 30 days, sometimes for years, so a back catalogue episode with 400 lifetime downloads is not the same thing as a new episode with 400 in a week. Second, category changes everything. A show about a narrow professional niche can be genuinely successful at 200 downloads an episode, because those 200 people are worth a great deal to the right sponsor, while a comedy show at 200 is struggling.

## What the counter is actually counting

A download is not a listener. It is an HTTP request for your audio file that lasted long enough to count under the IAB measurement guidelines, which most reputable hosts follow. That means:

- One person who listens to the same episode three times on three devices can generate more than one download.
- An app that automatically downloads new episodes for a subscriber who never presses play still generates a download.
- Someone who streams 45 seconds and bails may still be counted, depending on how much of the file transferred.
- Bots and prefetching are filtered out by good hosts, imperfectly.

So the number is a rough proxy for demand, not a headcount. Two shows with identical download numbers can have very different real audiences. This is also why comparing your host's numbers to a friend's on a different host is close to meaningless.

## Asking how many downloads is a successful podcast is usually the wrong question

Here is the part that actually helps. For most independent shows, the download count is a lagging, low resolution summary of things you cannot act on directly. It tells you something happened. It does not tell you what to do Monday morning.

Worse, it invites the wrong behavior. Chasing the number pushes people toward tactics that spike it briefly, like paid follow campaigns and reciprocal promotion swaps, and away from the slower work that grows a real audience. If your goal is a bigger number this month, you will make different decisions than if your goal is a show that 500 people genuinely rely on in two years.

If what you want is sponsors, the honest answer is that most sponsors care about audience quality and fit at least as much as raw volume, and plenty of shows under 1,000 downloads land paid deals. We went through how that conversation actually goes in [what sponsors look at before they say yes](/blog/how-to-get-podcast-sponsors).

## The numbers that tell you something you can use

Swap the download obsession for these four, all of which point at a decision.

**Completion rate.** How far into an episode the average listener gets. If people quit at minute four, your cold open is too long or your first segment is weak. This is the single most useful number in your dashboard and most hosts now report it.

**Followers and subscribers, and the direction they are moving.** A follow is a standing instruction to deliver your next episode. Total followers growing steadily is a healthier sign than any single episode's download spike.

**Repeat listening across episodes.** Of the people who heard episode 40, how many came back for 41? That ratio tells you whether you have an audience or a series of one night stands.

**Where new listeners come from.** If you cannot answer this, you cannot repeat anything that worked. Distinct traffic sources, whether that is search, a guest appearance, or a referral from another show, are the only thing you can deliberately do more of.

## How many podcast downloads is good when your feed is three months old

When people ask how many downloads is good for a new podcast, the answer is to calibrate low and stay patient. Most shows in their first three months sit in the single or double digits per episode, and that is normal rather than a verdict. A new feed has no back catalogue, no follower base, and no external pages pointing at it.

A reasonable first year looks like slow, uneven growth: a plateau for a few months, a bump when something outside the show sends people in, another plateau, then steadier climbing once you have enough episodes for people to binge. Shows that give up usually do so in month four, right before the catalogue gets big enough to compound. If you want the mechanics of that compounding, [where listeners actually come from](/blog/how-to-get-more-podcast-listeners) covers it in more detail.

## When the raw figure genuinely counts

There are three situations where you should care about the download number directly. When a sponsor or ad network asks for it, because that is the currency they buy in. When you are comparing your own episodes against each other to see which topics land. And when you are checking for a technical problem, since a sudden drop of 40% usually means a broken feed or a redirect gone wrong rather than an audience that left.

Outside those three, the number is a scoreboard you stare at rather than a lever you pull.

## Common questions

### What is a good podcast download number for a niche show?

Lower than you think. A show serving a specific profession or hobby can be commercially viable at a couple hundred downloads an episode, because advertisers pay for relevance. The general benchmarks in the table are for all podcasts at once and do not describe your category well.

### Why do my downloads drop the week after an episode goes out?

Because most downloads for any episode arrive in the first few days, when followers' apps fetch it automatically. A steep decline after week one is the normal shape, not a problem. Look at the 30 day total instead of the daily curve.

### Should I switch hosts to get better numbers?

Numbers can shift when you move hosts because filtering methods differ slightly, but that is measurement noise, not growth. Pick a host for reliability and analytics quality and then stop comparing across platforms.

## Where this connects to what we do

Download counts go up when more people who would like your show can find it, and the most reliable way to be found is to already be the answer to something people search for. PodAnswer turns your episodes into searchable articles that answer real questions, each quote timestamped back to the moment you said it. Have a look at [how it works for podcasters](/for-podcasters) or at [what it costs](/pricing).
