---
title: Podcast promotion services: what you're actually paying for
description: How to evaluate podcast promotion services and agencies. The questions to ask, the deliverables that count, and the offers that don't bring listeners.
date: 2026-09-02
---

Search "podcast promotion services" and you'll find everything from $20 Fiverr gigs to five-figure agency retainers. The prices vary wildly because the deliverables do. Here's how to tell them apart.

## The four things a service can actually do

**Get you found by strangers.** This means search articles, guest bookings on other shows, or paid placement in podcast apps and newsletters. It's the only category that brings people who didn't already know you.

**Reach people who already follow you.** Social clips, email newsletters, community posts. Useful, but it doesn't grow the top of the funnel.

**Make the show better.** Editing, titling, show notes, artwork. Necessary, but it isn't promotion.

**Make you feel promoted.** Directory submissions to 50 directories nobody uses, "featured" placements on sites with no traffic, follower packages. Skip these entirely.

## Questions to ask before you pay

1. Where do the new listeners come from? If the answer is vague ("our network", "our audience"), ask for a number.
2. What will I be able to see? You should get a report with readers, clicks, rankings or downloads, not a screenshot of a social post.
3. Does the work keep paying after I stop? Articles and guest appearances do. Paid ads and social posts don't.
4. Who owns what's created? You should own or be free to republish any content made from your show.

## What a fair deal looks like

For an independent educational show, a reasonable monthly service brings a defined number of new pages or placements, a dashboard, and a monthly report, for somewhere between one and four hundred dollars a month. Above that you should be getting guest booking, production, or ad spend included.

## How PodAnswer fits

We do the first category: getting you found by strangers, through search. Every month we turn your episodes into a set number of articles that answer real Google questions, publish them in your hub on the network, and show you the readers and clicks. [Pricing is here](/pricing) and there's a free listing if you want to see the network before committing.
